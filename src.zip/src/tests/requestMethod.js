import axios from "axios";
// const user = JSON.parse(localStorage.getItem("userData"));
// axios.defaults.headers.common={Authorization: 'Bearer E4hc6xlBl0MLTgGBv65QxTdFhtxdbv'}
const BASE_URL = "http://localhost:8000";

let TOKEN;

const user = JSON.parse(localStorage.getItem("userData"));
// console.log(user)

try {
  if (user.token) {
    TOKEN = user.token;
  }
} catch (err) {
  localStorage.setItem("currentUser", "{}");
}

export const publicRequest = axios.create({
  baseURL: BASE_URL,
});
// console.log(TOKEN)
// export const userRequest = axios.create({
//   baseURL: BASE_URL,
//   headers: { authorization: `token ${user.token}` }, //Remember to uncomment in live
// });

// export const userRequest = {
//   method: 'post',
//   maxBodyLength: Infinity,
//   url: 'localhost:8000/add_group',
//   headers: {
//     'token': 'token',
//     'Content-Type': 'application/json',
//     'Authorization': 'Bearer E4hc6xlBl0MLTgGBv65QxTdFhtxdbv'
//   }
// };

export const userRequest = axios.create({
  baseURL: BASE_URL,
  headers: { authorization: `${TOKEN}` },
});
