import { Paper, Typography } from "@mui/material"

const Welcome = ({ title, Icon, onClick, user }) => {
    return (
        <Paper
           
            sx={{
                padding: 2, 
                textAlign: 'center',
                color: 'black',
                width: 80,
                borderRadius: 0.5,
                justifyContent: 'flex-end',
                //display: 'flex'
                margin: 0.1
            }}
        >
            <div>Welcome, <strong>User</strong></div>
            <Typography variant="h6" component="h1">
                <img
                    src={Icon}
                />

            </Typography>
            <button>Sign out</button>
        </Paper>
    );
}

export default Welcome;