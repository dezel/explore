import { Box, Card, Paper, Typography, Button } from "@mui/material";
import React, { useEffect, useState } from "react";
import Popup from "./Popup";
import PaperNew from "./PaperNew";
import ReportIcon from './report_icon.svg'
import UserIcon from "./user_icon.svg";
import RegisterReport from "./RegisterReport";
import FormEdit from "./FormEdit";
import { userRequest } from "./requestMethod";
import Loader from "./Loader";


const Reports = ({
    showRegisterReport,
    setShowRegisterReport,
    showEditReport,
    setShowEditReport,
    children }) => {
    const [users, setUsers] = useState()
    const exportData = (data, fileName, type) => {
        const blob = new Blob([data], { type });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        a.click();
        window.URL.revokeObjectURL(url);
    };

    const handleExport = () => {
        setIsloading(true)
        userRequest.get('/export_users')
            .then((res) => {
                exportData(res.data, 'users.csv', 'text/csv;charset=utf-8;')
                setIsloading(false)
            })
            .catch((err) => {
                console.log(err)
                setIsloading(false)
            })
    }
    const [loading, setIsloading] = useState(false)
    return (
        <>
            <h3>Reports</h3>
            <Box
                sx={{
                    margin: '10px',
                    border: "none",
                    padding: '10px',
                    flexDirection: 'row',
                    display: 'flex',
                    height: '100%'
                }}
            >
                {children}

                <PaperNew onClick={() => setShowRegisterReport(true)} title="Register Report" Icon={UserIcon} />
                <PaperNew onClick={() => handleExport()} title="Download All Users" Icon={UserIcon} />

                <Popup
                    sx={{ minHeight: 800, width: 600, height: 600 }}
                    title={'Register Report'}
                    setOpenPopup={setShowRegisterReport}
                    openPopup={showRegisterReport}
                >
                    <RegisterReport />
                </Popup>
                
                <PaperNew title={'Edit Report'} Icon={ReportIcon} onClick={(e) => setShowEditReport(true)} />

                <Popup
                    sx={{ minHeight: 800, width: 600, height: 600 }}
                    title={'Edit Report'}
                    setOpenPopup={setShowEditReport}
                    openPopup={showEditReport}
                >
                    <FormEdit EditForm={true} />
                </Popup>
                <Loader isLoading={loading}/>
            </Box>
        </>
    )
}

export default Reports;