import ActionButton from "./ActionButton";
import Controls from "../controls/Controls";
import { FormControl, Grid2, Box } from "@mui/material";
import { Button } from "@mui/material";


const AssignReport = () => {
    return (
        <>
            <FormControl sx={{ minWidth: 500, minHeight: 500 }}>
                <Grid2 spacing={4} size={{ xs: 12, md: 12 }} container>
                    <Grid2 size={{ lg: 6, md: 6, xs: 6 }}>
                        <Controls.Input
                            size="small"
                            variant="standard"
                            name="surname"
                            onChange={() => { console.log('changed') }}
                            label="Surname"
                            fullWidth
                            required
                        >
                        </Controls.Input>
                        <Controls.Input
                            size="small"
                            variant="standard"
                            name="userName"
                            onChange={() => { console.log('changed') }}
                            label="Username"
                            fullWidth
                        ></Controls.Input>
                    </Grid2>
                    <Grid2 size={{ lg: 6, md: 6, xs: 6 }}>
                        <Controls.Input
                            size="small"
                            variant="standard"
                            name="otherNames"
                            onChange={() => { console.log('changed') }}
                            label="Other names"
                            fullWidth
                        ></Controls.Input>
                    </Grid2>
                </Grid2>
                <Box sx={{ flexGrow: 1 }}></Box>

                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    sx={{ mt: 2 }}
                >
                    Save
                </Button>
            </FormControl>
        </>
    )
}

export default AssignReport;