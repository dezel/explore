import React from "react";
import { TextField, InputAdornment } from "@mui/material";
import { ReactComponent as LockIcon } from "./lock.svg"; // Adjust the path as needed

const InputWithAdornment = () => {
  return (
    <TextField
      variant="outlined"
      label="Password"
      type="password"
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <LockIcon style={{ width: 20, height: 20 }} />
          </InputAdornment>
        ),
      }}
      fullWidth
    />
  );
};

export default InputWithAdornment;
