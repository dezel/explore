import { Box, Dialog, DialogContent, DialogTitle } from "@mui/material";
import "./popup.css";
import { Typography } from "@mui/material";



const Popup = ({ title, children, openPopup, setOpenPopup }) => {
    const myStyle = {
        height: 'auto',
        width: 'auto',

        // cursor: pointer
    }
    return (
        <Dialog sx={{ transition: 'opacity 5s' }} open={openPopup} maxWidth="md" className="dialog-wrapper">
            <DialogTitle className="dialog-title">
                <div style={{ display: "flex" }}>
                    <Typography variant="h6" component="div" style={{ flexGrow: 1 }}>
                        {title}
                    </Typography>
                    <Box
                        sx={{
                            cursor: "pointer",
                            '&:hover': {
                                backgroundColor: 'grey',
                                cursor: 'pointer',
                            },
                        }}
                        onClick={() => {
                            setOpenPopup(false);
                        }}
                        style={myStyle}>
                        <svg
                            style={{ fill: 'white' }}
                            sxmlns="http://www.w3.org/2000/svg"
                            height="18" width="18"
                            viewBox="0 0 18 18">
                            <title>Close</title>
                            <g strokeWidth="1.5" fill="none" stroke="#212121" className="nc-icon-wrapper">
                                <line x1="14" y1="4" x2="4" y2="14" strokeLinecap="round" strokeLinejoin="round" stroke="#212121"></line>
                                <line x1="4" y1="4" x2="14" y2="14" strokeLinecap="round" strokeLinejoin="round">
                                </line>
                            </g>
                        </svg>
                    </Box>
                </div>
            </DialogTitle>
            <DialogContent dividers>{children}</DialogContent>
        </Dialog>
    );
};

export default Popup;
