import React, { useState } from "react";
import { Grid, Paper, Box, Typography, TextField, Button } from "@mui/material";
import Home from "./Home";
import PaperNew from "./PaperNew";
import ReportIcon from './report_icon.svg'

const tiles = [
    { label: "Home", content: "Home Form" },
    { label: "About", content: "About Form" },
    { label: "Services", content: "Services Form" },
    { label: "Contact", content: "Contact Form" },
    { label: "FAQ", content: "FAQ Form" },
];

const forms = [
    // Form content for each tab
    () => (
        // <Box component="form" noValidate autoComplete="off">
        //     <TextField fullWidth label="Name" margin="normal" />
        //     <TextField fullWidth label="Message" margin="normal" multiline rows={4} />
        //     <Button variant="contained" color="primary" fullWidth>
        //         Submit
        //     </Button>
        // </Box>

        <PaperNew Icon={ReportIcon} onClick={() => setOpenAddReport(true)} />

    ),
    () => (
        <Box component="form" noValidate autoComplete="off">
            <TextField fullWidth label="Your Email" margin="normal" />
            <TextField fullWidth label="Feedback" margin="normal" multiline rows={4} />
            <Button variant="contained" color="primary" fullWidth>
                Send Feedback
            </Button>
        </Box>
    ),
    () => (
        <Box component="form" noValidate autoComplete="off">
            <TextField fullWidth label="Service Required" margin="normal" />
            <TextField fullWidth label="Additional Details" margin="normal" multiline rows={3} />
            <Button variant="contained" color="primary" fullWidth>
                Request Service
            </Button>
        </Box>
    ),
    () => (
        <Box component="form" noValidate autoComplete="off">
            <TextField fullWidth label="Name" margin="normal" />
            <TextField fullWidth label="Email" margin="normal" />
            <TextField fullWidth label="Message" margin="normal" multiline rows={3} />
            <Button variant="contained" color="primary" fullWidth>
                Contact Us
            </Button>
        </Box>
    ),
    () => (
        <Box component="form" noValidate autoComplete="off">
            <TextField fullWidth label="Question" margin="normal" />
            <Button variant="contained" color="primary" fullWidth>
                Submit Question
            </Button>
        </Box>
    ),
];

const TileTab = ({ label, selected, onClick }) => (
    <Paper
        elevation={selected ? 6 : 2}
        onClick={onClick}
        sx={{
            cursor: "pointer",
            padding: 2,
            margin: "8px 0",
            textAlign: "center",
            backgroundColor: selected ? "primary.main" : "background.paper",
            color: selected ? "white" : "text.primary",
            transition: "background-color 0.3s",
            "&:hover": {
                backgroundColor: selected ? "primary.dark" : "grey.100",
            },
        }}
    >
        <Typography variant="h6">{label}</Typography>
    </Paper>
);

const HomePage = () => {
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [openPopup, setOpenPopup] = useState(false);

    return (
        <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}>
            {/* Vertical Tiles */}
            <Grid
                item
                xs={3}
                sx={{
                    borderRight: "1px solid #ccc",
                    padding: 2,
                    height: "100%",
                    overflowY: "auto",
                }}
            >
                {tiles.map((tile, index) => (
                    <TileTab
                        key={index}
                        label={tile.label}
                        selected={selectedIndex === index}
                        onClick={() => setSelectedIndex(index)}
                    />
                ))}
            </Grid>

            {/* Content Area */}
            <Grid
                item
                xs={9}
                sx={{
                    padding: 4,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "column",
                }}
            >
                <Typography variant="h4" gutterBottom>
                    {tiles[selectedIndex].content}
                </Typography>
                {forms[selectedIndex]()}
            </Grid>
        </Box>
    );
};

export default HomePage;