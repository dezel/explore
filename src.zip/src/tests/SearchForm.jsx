import React, { useEffect, useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import Paper from "@mui/material/Paper";
import { userRequest } from "./requestMethod";
import { MenuItem, Select, InputAdornment, FormControl, InputLabel } from "@mui/material";
import CloseButton from './close-button-icon.svg'
import ConfirmationDialog from "./ConfirmationDialog";
import { ReactComponent as LockIcon } from "./lock.svg";

const SearchForm = ({ Deny, Group, User }) => {
    const [selectedResult, setSelectedResult] = useState([]);
    const [groups, setGroups] = useState([])
    const [reports, setReports] = useState([])
    const [searchString, setSearchString] = useState('')
    const [selectedGroup, setSelectedGroup] = useState('')
    const [confirmation, setConfirmation] = useState(false)
    const [message, setMessage] = useState('')
    const [title, setTitle] = useState('')


    const getGroups = async () => {
        await userRequest.post('/get_groups')
            .then((res) => {
                setGroups(res.data)
            }
            )
    }

    const getUsers = async () => {
        await userRequest.post('/get_groups')
            .then((res) => {
                setGroups(res.data)
            }
            )
    }

    // console.log(Deny)
    const searchReports = (e) => {
        setSearchString(e.target.value)
        const postData = { searchString: searchString }
        if (searchString.length > 2) {
            userRequest.post('/search_report', postData)
                .then((res) => {
                    setReports(res.data)
                })
        }
    }


    useEffect(() => {
        getGroups()
    }, [])


    const handleAssign = () => {

        const individualFormData = {

        }
        const groupFormData = {
            group: {
                group_id: selectedGroup,
                reports: selectedResult
            }
        }
        console.log(groupFormData)

        if (Group) {
            userRequest.post('/assign_report_group', groupFormData)
                .then((res) => console.log(res))
                .then(
                    setSelectedResult([])
                )
        } else {
            userRequest.post('/assign_report_group', individualFormData)
                .then((res) => {
                    setMessage('Report access updated successfully')
                    setTitle('Success')
                    setConfirmation(true)
                    setSelectedResult([])
                }
                )
                .catch((err)=>{
                    setMessage('Report update failed')
                    setTitle('Failed')
                    setConfirmation(true)
                })
        }
    }

    const handleDeny = () => {

        if (Group) {

        }
        else {
            const individualFormData = {
                user: { USER_ID: User.USER_ID, REPORT_ID: selectedResult }
            }
            console.log(individualFormData)

            userRequest.post('/deny_report_individual', individualFormData)
                .then((res) => {
                    setMessage('Report access updated successfully')
                    setTitle('Success')
                    setConfirmation(true)
                })
                .catch((res) => {
                    setMessage('Report update failed')
                    setTitle('Failed')
                    setConfirmation(true)
                    console.log(res)
                })
        }

    }

    const handleGroupChange = (event) => {
        const { name, value, key } = event.target
        setSelectedGroup(value)
        const postData = { group_id: value }
        setSelectedResult([])
        userRequest.post('/get_group_report', postData)
            .then((res) => {
                setSelectedResult(res.data)
            }
            )
    }

    const handleIndividualChange = (event) => {
        const { name, value, key } = event.target
        console.log(value)
        setSelectedGroup(value)
        const postData = { group_id: value }
        setSelectedResult([])
        userRequest.post('/get_group_report', postData)
            .then((res) => {
                console.log(res.data)
                setSelectedResult(res.data)
            })
    }


    const handleGroupUnassign = (unassignedReport) => {
        console.log(selectedResult)
        setSelectedResult(selectedResult.filter((result) => result.REPORT_ID !== unassignedReport.REPORT_ID))


    }

    const handleResultClick = (result) => {
        if (!(selectedResult.some(x => x.REPORT_ID === result.REPORT_ID))) {
            setSelectedResult(r => [...r, result])
        }
        setReports([]); // Close the floating result box
        setSearchString('')
    };

    return (
        <Box sx={{ maxHeight: 800, maxWidth: 500, width: 500, margin: "0 auto", textAlign: "center", position: "relative", fontSize: 14 }}>
            {
                Group ? <>
                    <FormControl fullWidth>
                        <InputLabel>Group...</InputLabel>
                        <Select
                            fullWidth
                            onChange={handleGroupChange}
                            label="Select Group"
                            sx={{ fontSize: 14, padding: 1 }}
                            defaultValue=''
                        >
                            {
                                groups.map((group) => <MenuItem sx={{ fontSize: 14, padding: 1 }} key={group.GROUP_ID} value={group.GROUP_ID} >{group.GROUP_NAME}</MenuItem>)
                            }
                        </Select>
                    </FormControl>
                </> :
                    <TextField
                        slotProps={{
                            input: {

                                endAdornment: (
                                    <InputAdornment position="end">
                                        {<LockIcon style={{ width: 20, height: 20 }} />}
                                    </InputAdornment>
                                )
                            }
                        }}
                        value={User.USER_ID}></TextField>
            }

            <TextField
                label="Search report"
                inputProps={{ style: { fontSize: 14 } }}
                onChange={searchReports}
                fullWidth
                margin="normal"
                value={searchString}
            />
            {reports.length > 1 && (
                <Paper
                    sx={{
                        position: "fixed", // Ensure the results float above all content
                        top: "32%", // Adjust as needed for vertical placement
                        left: "50%", // Center horizontally
                        transform: "translateX(-50%)", // Adjust horizontal centering
                        zIndex: 1000, // High z-index to float above other elements
                        maxHeight: 200,
                        width: "32%", // Adjust width as needed
                        overflowY: "auto",
                        border: "1px solid #ccc",
                        borderRadius: 2,
                        backgroundColor: "white",
                        fontSize: 10
                    }}
                    elevation={3}
                >
                    <List inputProps={{
                        style: {
                            fontSize: 14,
                            '&:hover': {
                                backgroundColor: 'grey',
                                cursor: 'pointer',
                            }
                        }
                    }}>
                        {reports.map((report) => (
                            <ListItem inputProps={{
                                style: {
                                    fontSize: 14, '&:hover': {
                                        backgroundColor: 'grey',
                                        cursor: 'pointer',
                                    }
                                }
                            }
                            } button key={report.REPORT_ID} onClick={() => handleResultClick(report)}>
                                <Box sx={{
                                    fontSize: 14
                                }}>{report.REPORT_NAME}</Box>
                            </ListItem>
                        ))}
                    </List>
                </Paper>
            )}
            <Box sx={{ overflow: "scroll", height: 300, minHeight: 150, marginTop: 2, marginBottom: 2, padding: 1, border: "1px solid #ccc", borderRadius: 2 }}>
                {
                    selectedResult.map(result => (<ListItem sx={{
                        '&:hover': {
                            backgroundColor: '#d4d2d2',
                            cursor: 'pointer'
                        }
                    }}
                        key={result.REPORT_ID}>{result.REPORT_NAME}<img onClick={() => handleGroupUnassign(result)} style={{ width: 15, height: 15 }} alt="" src={CloseButton}></img></ListItem>))
                }
            </Box>
            <Button
                variant="contained"
                color="primary"
                onClick={Deny ? handleDeny : handleAssign}
                fullWidth
            >
                {Deny ? 'Deny' : 'Assign'}
            </Button>
            {confirmation &&
                <ConfirmationDialog
                    message={message}
                    onConfirm={() => {
                        setConfirmation(false)
                        // setFormData('')
                    }}
                    title={title}
                />
            }
        </Box>
    );
};

export default SearchForm;
