import React, { useState } from 'react';
import './confirmationDialog.css'; // Import your CSS file for styling
import Controls from "../controls/Controls";

function ConfirmationDialog({ message, onConfirm,title,onCancel, showCancel, addMessage }) {
  return (
    <div className="confirmation-dialog">
      <div className="confirmation-content">
        <h3>{title}</h3>
        <p>{message}</p>
        {addMessage &&
          <Controls
            name="deleteMessage"
            label="Please give reason"
            required
            // onChange={(e) => setUsername(e.target.value)}
            size="small"
            // value={username}
          />
        }
        <div>-</div>
        <button onClick={onConfirm}>Ok</button>
        {showCancel &&
          (<button onClick={onCancel}>Cancel</button>)
        }
      </div>
    </div>
  );
}

export default ConfirmationDialog;