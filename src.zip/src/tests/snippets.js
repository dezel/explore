//hover color change
<Box
  sx={{
    width: 100,
    height: 100,
    borderRadius: 1,
    bgcolor: "primary.main",
    "&:hover": {
      bgcolor: "primary.dark",
      cursor: "pointer",
    },
  }}
/>;
