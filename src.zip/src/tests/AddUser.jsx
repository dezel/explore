import Controls from "../controls/Controls";
import { FormControl, Grid2, Box, Menu, ListItem, TextField, InputAdornment } from "@mui/material";
import { Button } from "@mui/material";
import { userRequest, publicRequest } from "./requestMethod";
import { useEffect, useState } from "react";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormLabel from '@mui/material/FormLabel';
import ConfirmationDialog from "./ConfirmationDialog";
import Loader from "./Loader";
import { ReactComponent as LockIcon } from "./lock.svg";

// let currentUser = JSON.parse(localStorage.getItem('userData'))

const AddUser = ({ User, EditMode }) => {

    // const user = localStorage.getItem("userData");
    const [user, setUser] = useState(JSON.parse(localStorage.getItem("userData")))

    const [confirmation, setConfirmation] = useState(false)
    const [message, setMessage] = useState('')
    const [title, setTitle] = useState('')
    const [groups, setGroups] = useState([])
    const [selectedResult, setSelectedResult] = useState([]);
    const [searchString, setSearchString] = useState('')
    const [showGroups, setShowGroups] = useState(false)
    const [loading, setLoading] = useState(false)

    const groupInfo = {
        selectedResult
    }

    useEffect(() => {
        setUser(JSON.parse(localStorage.getItem("userData")));
    }, [])


    const [formData, setFormData] = useState({
        surname: User ? User.SURNAME : "",
        otherNames: User ? User.OTHER_NAMES ? User.OTHER_NAMES : '' : "",
        username: User ? User.USER_ID : "",
        active: User ? User.STATUS == 'D' ? false : true : true,
        accessLevel: User ? User.USER_ACCESS_LEVEL : 3,
        accessCode: User ? User.ACCESS_CODE : "",
        authenticationType: User ? User.AUTH_TYPE : "AD",
        userType: User ? (User.USER_TYPE ? User.USER_TYPE : "User") : "User",
        createdBy: User ? User.CREATED_BY : user ? user.username : "",
    });



    const searchReports = (e) => {
        setSearchString(e.target.value)
        const postData = { searchString: searchString }
        if (searchString.length > 2) {
            userRequest.post('/search_report', postData)
                .then((res) => {
                    // setGroups(res.data)
                    // console.log(res.data)
                })
        }
    }


    const handleGroupUnassign = (unassignedReport) => {
        setSelectedResult(selectedResult.filter((result) => result.GROUP_ID !== unassignedReport.GROUP_ID))

    }


    const handleChange = (event) => {
        const { name, value, type, checked } = event.target;

        setFormData((prevData) => ({
            ...prevData,
            [name]: type === "checkbox" ? checked : value,
            groups: selectedResult,
        }));
    };

    const handleResultClick = (result, event) => {
        setShowGroups(false)
        if (!(selectedResult.some(x => x.GROUP_ID === result.GROUP_ID))) {
            setSelectedResult(r => [...r, result])
        }

    };

    const handleSubmit = (e) => {
        setLoading(true)
        e.preventDefault()

        if (EditMode) {
            userRequest.post('/edit_user', formData)
                .then((res) => {
                    setMessage('User updated successfully')
                    setTitle('Success')
                    setConfirmation(true)
                    setLoading(false)
                })
                .catch((res) => {
                    setMessage('User update failed')
                    setTitle('Failed')
                    setConfirmation(true)
                    // console.log(res)
                    setLoading(false)
                })

        }
        else {
            console.log(formData)
            userRequest.post('/add_user', formData)

                .then((res) => {
                    setMessage('User updated successfully')
                    setTitle('Success')
                    setConfirmation(true)
                    setLoading(false)

                })
                .catch((res) => {
                    setMessage('User addition failed')
                    setTitle('Failed')
                    setConfirmation(true)
                    setLoading(false)

                })
        }
    }



    return (
        <>
            <FormControl sx={{ minWidth: 250, width: 300, margins: 5 }}>
                <Grid2 spacing={4} size={{ xs: 12, md: 12 }} container>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="username"
                        onChange={handleChange}
                        label="User ID"
                        fullWidth
                        required
                        slotProps={{
                            input: {
                                readOnly: EditMode,

                                endAdornment: (
                                    <InputAdornment position="end">
                                        {EditMode?<LockIcon style={{ width: 20, height: 20 }} />:<></>}
                                    </InputAdornment>
                                )
                            }
                        }}
                        value={formData.username}
                    ></Controls.Input>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="otherNames"
                        required
                        onChange={handleChange}
                        label="Other names"
                        fullWidth
                        value={formData.otherNames}
                    ></Controls.Input>
                    {/* <Grid2 size={{ lg: 6, md: 6, xs: 6 }}> */}
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="surname"
                        onChange={handleChange}
                        label="Surname"
                        fullWidth
                        required
                        value={formData.surname}
                    >
                    </Controls.Input>
                    <FormControl>
                        <FormLabel id="demo-radio-buttons-group-label">Authentication Type</FormLabel>
                        <RadioGroup
                            defaultValue="AD"
                            name="authenticationType"
                            value={formData.authenticationType}
                            onChange={handleChange}
                            sx={{ marginLeft: 1 }}
                        >
                            <Grid2>

                                <FormControlLabel value="AD" control={<Radio />} label="AD" />
                                <FormControlLabel value="LD" control={<Radio />} label="LD" />
                            </Grid2>
                        </RadioGroup>
                    </FormControl>
                    <FormControl
                        fullWidth
                        variant="standard"
                    // style={{ margin: -2 }}
                    >
                        <InputLabel id="select-label">Select access level</InputLabel>
                        <Select
                            labelId="select-label"
                            value={formData.accessLevel}
                            onChange={handleChange}
                            name="accessLevel"
                            defaultValue={formData.accessLevel}
                        >
                            <MenuItem value={1}>Level 1</MenuItem>
                            <MenuItem value={2}>Level 2</MenuItem>
                            <MenuItem value={3}>Level 3</MenuItem>
                            <MenuItem value={4}>Level 4</MenuItem>
                            <MenuItem value={5}>Level 5</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControlLabel
                        control={<Checkbox sx={{ margin: -1 }} name='active' checked={formData.active} onChange={handleChange} />}
                        label="Active"
                        sx={{ margin: -1 }}
                    />
                    <FormControl variant="standard" fullWidth style={{ margin: -1 }}>
                        <InputLabel id="select-label">Select user type</InputLabel>
                        <Select
                            labelId="select-label"
                            // value={formData.userType}
                            defaultValue={User ? User.USER_TYPE : 'User'}
                            onChange={handleChange}
                            name="userType"
                        >
                            <MenuItem value="Administrator">Administrator</MenuItem>
                            <MenuItem value="User">User</MenuItem>
                        </Select>
                    </FormControl>
                </Grid2>
                <Box sx={{ flexGrow: 1 }}></Box>
                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    sx={{ mt: 2 }}
                    onClick={handleSubmit}
                >
                    Save
                </Button>
            </FormControl>
            {confirmation &&
                <ConfirmationDialog
                    message={message}
                    onConfirm={() => {
                        setConfirmation(false)
                        // setFormData('')
                    }}
                    title={title}
                />
            }
            <Loader isLoading={loading} />
        </>
    )
}

export default AddUser;