import Controls from "../controls/Controls";
import { FormControl, Grid2, Box, Menu } from "@mui/material";
import { Button } from "@mui/material";
import { userRequest, publicRequest } from "./requestMethod";
import { useEffect, useState } from "react";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import ConfirmationDialog from "./ConfirmationDialog";



const AddGroup = () => {
    const [confirmation, setConfirmation] = useState(false)
    const [message, setMessage] = useState('')
    const [title, setTitle] = useState('')


    const [formData, setFormData] = useState({
        groupName: ""
    });

    const handleChange = (event) => {
        const { name, value, type, checked } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault()
        
        userRequest.post('add_group', formData)                
        .then((res) => {
            setMessage('Group added successfully')
            setTitle('Success')
            setConfirmation(true)
        })
        .catch((res) => {
            setMessage('Failed to add group')
            setTitle('Failed')
            setConfirmation(true)
        })
    }



    return (
        <>
            <FormControl sx={{ minWidth: 300 }}>
                <Grid2 spacing={4} size={{ xs: 12, md: 12 }} container>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="groupName"
                        required
                        onChange={handleChange}
                        label="Group name"
                        fullWidth
                        value={formData.groupName}
                        sx={{margin:0}}
                    ></Controls.Input>
                </Grid2>
                <Box sx={{ flexGrow: 1 }}></Box>
                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    sx={{ mt: 2 }}
                    onClick={handleSubmit}
                >
                    Save
                </Button>
            </FormControl>
            {confirmation &&
                <ConfirmationDialog
                    message={message}
                    onConfirm={() => {
                        setConfirmation(false)
                        // setFormData('')
                    }}
                    title={title}
                />
            }
        </>
    )
}

export default AddGroup;