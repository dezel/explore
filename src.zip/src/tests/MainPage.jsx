import { useEffect, useState } from "react";
import { Grid2, Box } from "@mui/material";
import MenuItem from "./MenuItems";
import Home from "./Home";
import SettingsIcon from "./cog.svg";
import HomeIcon from "./home.svg";
import ReportIcon from "./report_icon.svg";
import PaperNew from "./PaperNew";
import GroupIcon from "./group_icon.svg";
import UserIcon from "./user_icon.svg";
import Welcome from "./Welcome";
import Users from "./Users";
import Reports from "./Reports";
import Groups from "./Groups";
import Settings from "./Settings";
import Navbar from "../forms/Navbar";

function MainPage() {
    const [showHome, setShowHome] = useState(false);
    const [openPopup, setOpenPopup] = useState(false);
    const [showUsers, setShowUsers] = useState(false);
    const [showGroups, setShowGroups] = useState(false);
    const [showReports, setShowReports] = useState(false);
    const [showSettings, setShowSettings] = useState(false);

    const [showAddUser, setAddUser] = useState(false);
    const [openAssignReportPopup, setOpenAssignReportPopup] = useState(false);
    const [openAddGroup, setOpenAddGroup] = useState(false);
    const [showRegisterReport, setShowRegisterReport] = useState(false);
    const [showDenyReport, setShowDenyReport] = useState(false);
    const [showEditUser, setShowEditUser] = useState(false);
    const [bgColor, setBgColor] = useState("");


    const handleSwitch=({name})=>{


    }

    return (
        <>
            <Navbar />
            <Box>
                <Box sx={{ width: "25%", display: "flex", flexDirection: "row" }}>
                    <Box
                        sx={{
                            color: "#3e000c",
                            margin: 2,
                            display: "flex",
                            flexDirection: "row",
                        }}
                    >
                        <MenuItem
                            onClick={() => {
                                console.log("Home Menu clicked");
                                setShowHome(true);
                                setShowGroups(false);
                                setShowReports(false);
                                setShowSettings(false);
                                setShowUsers(false);
                                setBgColor("cyan");
                            }}
                            backgroundColor={bgColor}
                            title={"Home"}
                            Icon={HomeIcon}
                        />
                        <MenuItem
                            onClick={() => {
                                console.log("Users Menu clicked");
                                setShowHome(false);
                                setShowGroups(false);
                                setShowReports(false);
                                setShowSettings(false);
                                setShowUsers(true);
                            }}
                            backgroundColor={bgColor}
                            title={"Users"}
                            Icon={UserIcon}
                        />
                        <MenuItem
                            onClick={() => {
                                console.log("Group Menu clicked");
                                setShowHome(false);
                                setShowGroups(true);
                                setShowReports(false);
                                setShowSettings(false);
                                setShowUsers(false);
                            }}
                            title={"Groups"}
                            Icon={GroupIcon}
                        />
                        <MenuItem
                            onClick={() => {
                                console.log("Reports menu clicked");
                                setShowHome(false);
                                setShowGroups(false);
                                setShowReports(true);
                                setShowSettings(false);
                                setShowUsers(false);
                            }}
                            title={"Reports"}
                            Icon={ReportIcon}
                        ></MenuItem>
                        <MenuItem
                            onClick={() => {
                                console.log("Settings menu clicked");
                                setShowHome(false);
                                setShowGroups(false);
                                setShowReports(false);
                                setShowSettings(true);
                                setShowUsers(false);
                            }}
                            backgroundColor
                            title={"Settings"}
                            Icon={SettingsIcon}
                        ></MenuItem>
                    </Box>
                </Box>
                {showHome && (
                    <Home
                        sx={{ bagroundColor: "pink" }}
                        open={openPopup}
                        setOpenPopup={setOpenPopup}
                    ></Home>
                )}
                {showUsers && (
                    <Users
                        openAddUser={showAddUser}
                        setOpenAddUser={setAddUser}
                        setShowDenyReport={setShowDenyReport}
                        showDenyReport={showDenyReport}
                        openEditUser={showEditUser}
                        setEditUser={setShowEditUser}
                    />
                )}
                {showReports && (
                    <Reports
                        openAssignReportPopup={openAssignReportPopup}
                        setOpenAssignReportPopup={setOpenAssignReportPopup}
                        setShowRegisterReport={setShowRegisterReport}
                        showRegisterReport={showRegisterReport}
                    />
                )}
                {showGroups && (
                    <Groups
                        openAddGroup={openAddGroup}
                        setOpenAddGroup={setOpenAddGroup}
                    />
                )}
                {showSettings && <Settings />}
            </Box>
        </>

    )

}
export default MainPage;