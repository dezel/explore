import { Paper, Card, Box } from "@mui/material";

const PaperNew = ({ Icon, onClick, title }) => {
    return (
        <>
            <Paper
                onClick={onClick}
                elevation={10}
                sx={{
                    backgroundColor: 'white',
                    height: 80,
                    width: 80,
                    '&:hover': {
                        backgroundColor: '#fc831a',
                        cursor: 'pointer',
                        // height: '90px',
                        // width: '90px'
                    },
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    margin: '15px',
                    justifyContent: 'center',
                    border: '1px solid',
                    color: '#7c0b2b',
                    transition: "background-color 0.3s ease"
                }}
            ><Box sx={{ justifyContent: 'center', justifyItems: "center", width: '50px', height: '50px' }}>
                    <img
                        src={Icon}
                        alt=""
                        style={{
                            justifyContent: 'center',
                            alignItems: 'center',
                            display: 'flex',
                            height: '30px',
                            width: '30px',
                            margin: '0px'
                        }}
                    />
                    <h6 style={{ marginTop: '2px' }}>{title}</h6>
                </Box>
            </Paper>
        </>
    )
}

export default PaperNew;