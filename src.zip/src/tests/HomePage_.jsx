import React, { useState } from 'react';
import { Grid2, Paper, Box, Typography } from '@mui/material';
import Navbar from '../forms/Navbar';
import { Routes, useNavigate } from "react-router-dom";
import { Router } from 'react-router-dom';
import MenuItem from './MenuItems';

const tiles = [
    { label: "Home", content: "Welcome to the Home Section!" },
    { label: "Users", content: "Learn more about our mission and team." },
    { label: "Groups", content: "Discover the services we offer." },
    { label: "Reports", content: "Reach out to us via email or phone." },
    { label: "Settings", content: "Frequently Asked Questions answered here." },
];

const TileTab = ({ label, selected, onClick }) => (
    <Paper
        elevation={selected ? 6 : 2}
        onClick={onClick}
        sx={{
            cursor: "pointer",
            padding: 2,
            margin: "8px 0",
            textAlign: "center",
            backgroundColor: selected ? "primary.main" : "background.paper",
            color: selected ? "white" : "text.primary",
            transition: "background-color 0.3s",
            '&:hover': {
                backgroundColor: selected ? "primary.dark" : "grey.100",
            },
        }}
    >
        <Typography variant="h6">{label}</Typography>
    </Paper>
);

const HomePage = () => {
    const [selectedIndex, setSelectedIndex] = useState(0);

    return (
        <>
            {/* <Router>
                <Routes>

                    <Navbar />
                </Routes> */}
            {/* </Router> */}
            <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}>
                {/* Vertical Tiles */}
                <Grid2
                    item
                    xs={3}
                    sx={{
                        borderRight: "1px solid #ccc",
                        padding: 2,
                        height: "100%",
                        overflowY: "auto",
                    }}
                >
                    {tiles.map((tile, index) => (
                        <TileTab
                            key={index}
                            label={tile.label}
                            selected={selectedIndex === index}
                            onClick={() => setSelectedIndex(index)}
                        />
                    ))}
                </Grid2>
                <MenuItem
                            // onClick={() => {
                            //     console.log("Home Menu clicked");
                            //     setShowHome(true);
                            //     setShowGroups(false);
                            //     setShowReports(false);
                            //     setShowSettings(false);
                            //     setShowUsers(false);
                            //     setBgColor("cyan");
                            // }}
                            // backgroundColor={bgColor}
                            title={"Home"}
                            // Icon={HomeIcon}
                        />
                {/* Content Area */}
                <Grid2
                    item
                    xs={9}
                    sx={{
                        padding: 4,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                    }}
                >
                    <Typography variant="h5">{tiles[selectedIndex].content}</Typography>
                </Grid2>
            </Box>
        </>
    );
};

export default HomePage;