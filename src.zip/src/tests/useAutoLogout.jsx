import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const AUTO_LOGOUT_TIME = 3 * 60 * 1000; // 3 minutes

const useAutoLogout = (logoutFunction) => {
  const navigate = useNavigate();

  useEffect(() => {
    let timeout;

    const resetTimer = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        logoutFunction();
        navigate("/login"); // Redirect to login page
      }, AUTO_LOGOUT_TIME);
    };

    const handleUserActivity = () => {
      resetTimer();
    };

    // Listen for user interactions
    window.addEventListener("mousemove", handleUserActivity);
    window.addEventListener("keydown", handleUserActivity);
    window.addEventListener("click", handleUserActivity);

    resetTimer(); // Start the timer initially

    return () => {
      clearTimeout(timeout);
      window.removeEventListener("mousemove", handleUserActivity);
      window.removeEventListener("keydown", handleUserActivity);
      window.removeEventListener("click", handleUserActivity);
    };
  }, [logoutFunction, navigate]);
};

export default useAutoLogout;
