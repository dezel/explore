const Veggies = [
    { id: 1, name: "avocado", calories: 95 },
    { id: 2, name: "tomato", calories: 45 },
    { id: 3, name: "garden egg", calories: 105 },
    { id: 4, name: "turkey berry", calories: 159 },
    { id: 5, name: "onion", calories: 210 },
    { id: 6, name: "pepper", calories: 198 },
]

export default Veggies