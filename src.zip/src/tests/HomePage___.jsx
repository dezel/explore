import React, { useState } from "react";
import { Grid, Paper, Box, Typography, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Grid2 } from "@mui/material";

const tiles = [
  { label: "Home", content: "Home Section", pathto:'/home'},
  { label: "Users", content: "About Section" },
  { label: "Group", content: "Services Section" },
  { label: "Contact", content: "Contact Section" },
  { label: "FAQ", content: "FAQ Section" },
];

const forms = [
  () => (
    <>
      <TextField fullWidth label="Name" margin="normal" />
      <TextField fullWidth label="Message" margin="normal" multiline rows={4} />
    </>
  ),
  () => (
    <>
      <TextField fullWidth label="Your Email" margin="normal" />
      <TextField fullWidth label="Feedback" margin="normal" multiline rows={4} />
    </>
  ),
  () => (
    <>
      <TextField fullWidth label="Service Required" margin="normal" />
      <TextField fullWidth label="Additional Details" margin="normal" multiline rows={3} />
    </>
  ),
  () => (
    <>
      <TextField fullWidth label="Name" margin="normal" />
      <TextField fullWidth label="Email" margin="normal" />
      <TextField fullWidth label="Message" margin="normal" multiline rows={3} />
    </>
  ),
  () => (
    <>
      <TextField fullWidth label="Question" margin="normal" />
    </>
  ),
];

const TileTab = ({ label, selected, onClick }) => (   
  <Paper
    elevation={selected ? 6 : 2}
    onClick={onClick}
    sx={{
      cursor: "pointer",
      padding: 2,
      margin: "8px 0",
      textAlign: "center",
      backgroundColor: selected ? "primary.main" : "background.paper",
      color: selected ? "white" : "text.primary",
      transition: "background-color 0.3s",
      "&:hover": {
        backgroundColor: selected ? "primary.dark" : "grey.100",
      },
    }}
  >
    <Typography variant="h6">{label}</Typography>
  </Paper>
);

const HomePage = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [open, setOpen] = useState(false);

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}>
      {/* Vertical Tiles */}
      <Grid2
        item
        xs={3}
        sx={{
          borderRight: "1px solid #ccc",
          padding: 2,
          height: "100%",
          overflowY: "auto",
        }}
      >
        {tiles.map((tile, index) => (
          <TileTab
            key={index}
            label={tile.label}
            selected={selectedIndex === index}
            onClick={() => setSelectedIndex(index)}
          />
        ))}
      </Grid2>

      {/* Content Area */}
      <Grid2
        item
        xs={9}
        sx={{
          padding: 4,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
        }}
      >
        <Typography variant="h4" gutterBottom>
          {tiles[selectedIndex].content}
        </Typography>
        <Button variant="contained" color="primary" onClick={handleOpen}>
          Open {tiles[selectedIndex].label} Form
        </Button>

        <Button>Name</Button>
      </Grid2>

      {/* Dialog for Form */}
      {/* <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm">
        <DialogTitle>{tiles[selectedIndex].label} Form</DialogTitle>
        <DialogContent>
          {forms[selectedIndex]()}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleClose} variant="contained" color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog> */}
    </Box>
  );
};

export default HomePage;