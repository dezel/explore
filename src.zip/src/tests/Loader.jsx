import Loading from './loader.svg'


const Loader = ({ isLoading }) => {
    const myStyle = {
        height: 'auto',
        width: 'auto',

        // cursor: pointer
    }
    return (
        <img alt='' style={{
            justifyContent: 'center',
            alignItems: 'center',
            display: isLoading?'block':'none',
            height: '70px',
            width: '70px',
            margin: '0px',
            transition: 'opacity 5s',
            position: 'fixed',
            overflowY: 'auto',
            boxShadow: 'rgba(0, 0, 0, 0.2) 0px 11px 15px 0px, rgba(0, 0, 0, 0.14) 0px 24px 38px 3px, rgba(0, 0, 0, 0.12) 0px 9px 46px 1000px',
            color: 'rgba(0, 0, 0, 0.87)',
            borderRadius: '50%',
            transitionProperty: 'box-shadow',
            backgroundColor: 'rgb(255, 255, 255)',
            backgroundImage: 'none',
            outlineColor: 'rgb(0, 0, 0)',
            right: '50%',
            top: '50%',
            zIndex: 1300

        }}
            src={Loading}></img>
    );
};

export default Loader;
