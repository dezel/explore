import Popup from "./Popup";
import { styled } from "@mui/material/styles";
import useTable from "./useTable";
import {
    TableBody,
    TableRow,
    TableCell,
    Button,
    TextField,
} from "@mui/material";

import { tableCellClasses } from "@mui/material/TableCell";
import { useState } from "react";
import SearchForm from "./SearchForm";
import { userRequest } from "./requestMethod";
import AddUser from "./AddUser";
import SearchIcon from './magnifier.svg'
import AssignUserGroup from './AssignUserGroup'
import Loader from "./Loader";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.body}`]: {
        fontSize: 15,
        fontWeight: "300",
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:hover": {
        backgroundColor: "#fffbf2",
        cursor: "pointer",
    },
}));

// INITIALIZE TABLE HEAD INFO
const headCells = [
    { id: "user_id", label: "User ID" },
    { id: "other_names", label: "Other Names" },
    { id: "surname", label: "Surname" }
];
const btnPrimary = {
    minWidth: 0,
    margin: "3px",
    backgroundColor: "#3c44b126",
    color: "#333996",
};



const UserEdit = ({ EditUser, GroupAssign }) => {

    const [denyPopup, setDenyPopup] = useState(false)
    const [editPopup, setEditPopup] = useState(false)
    const [assigGroups, setAssignGroups] = useState(false)

    const [searchString, setSearchString] = useState('')
    const [users, setUsers] = useState()
    const [selectedUser, setSelectedUser] = useState()
    const [groups, setGroups] = useState()
    const [loading, setLoading] = useState(false)

    const searchUser = (event) => {
        setLoading(true)
        event.preventDefault();

        (userRequest.post('/search_users', { userName: searchString }))
            .then((res) => {
                setUsers(res.data)
                setLoading(false)
            })
    }
    
    const { TblContainer, TblHead } =
        useTable(users ? users : {});
    return (
        <>
            <TextField
                variant="standard"
                sx={{
                    marginBottom: 5,
                    marginLeft: 3
                }}
                onChange={(e) => setSearchString(e.target.value)}
            >
            </TextField>
            <Button onSubmit={searchUser} type="submit" variant="primary" color="primary" onClick={searchUser}>
                <img src={SearchIcon} alt=""
                    style={{
                        justifyContent: 'center',
                        alignItems: 'center',
                        display: 'flex',
                        height: '20px',
                        width: '20px',
                        margin: '0px'
                    }}
                ></img>Search</Button>
            {
                users ? <>
                    <TblContainer>
                        <TblHead headCells={headCells} />
                        <TableBody>
                            {users.map((user) => (
                                <StyledTableRow
                                    key={user.USER_ID}
                                >
                                    <StyledTableCell>{user.USER_ID}</StyledTableCell>
                                    <StyledTableCell>{user.OTHER_NAMES}</StyledTableCell>
                                    <StyledTableCell>{user.SURNAME}</StyledTableCell>
                                    <StyledTableCell>
                                        {
                                            EditUser
                                                ?
                                                <>
                                                    <Button
                                                        style={btnPrimary}
                                                        onClick={() => {
                                                            setSelectedUser(user)
                                                            setEditPopup(true)
                                                        }
                                                        }
                                                    >
                                                        Edit
                                                    </Button>

                                                    <Button
                                                        style={btnPrimary}
                                                        onClick={() => {
                                                            setAssignGroups(true)
                                                            setSelectedUser(user)

                                                            setSelectedUser((prevData) => ({
                                                                ...prevData,
                                                                groups
                                                            }))
                                                        }
                                                        }
                                                    >
                                                        Assign Group
                                                    </Button>
                                                </>
                                                :
                                                <>
                                                    <Button
                                                        style={btnPrimary}
                                                        onClick={() => {
                                                            setDenyPopup(true)
                                                            setSelectedUser(user)
                                                        }}
                                                    >
                                                        Open
                                                    </Button>

                                                </>
                                        }
                                    </StyledTableCell>
                                </StyledTableRow>
                            ))}
                        </TableBody>
                    </TblContainer>
                    <Popup setOpenPopup={setEditPopup} openPopup={editPopup}
                        title={"Edit User"}>
                        <AddUser User={selectedUser} EditMode={true} />
                    </Popup>
                    <Popup setOpenPopup={setDenyPopup} openPopup={denyPopup} title={"Deny User Report"}>
                        <SearchForm User={selectedUser} Group={false} Deny={true} />
                    </Popup>
                    <Popup setOpenPopup={setAssignGroups} openPopup={assigGroups} title={"Assign group"}>
                        <AssignUserGroup User={selectedUser} Group={false} />
                    </Popup>
                </> :
                    <></>
            }
                    <Loader isLoading={loading}/>
        </>
    );
};

export default UserEdit;