import React, { useState } from "react";
import Fruits from "./Fruites";
import Veggies from "./Veggies";
import UserExceptionReportMap from './da_rpt_user_exception_map.json'
import UserReportMap from './da_rpt_user_map.json'
import _UserGroups from './da_user_groups.json'
import UserGroupMap from './da_user_groups_map.json'
import { Grid2, Button, Box, backdropClasses } from "@mui/material";
import Controls from "../controls/Controls";


function FruitOperations() {
    const [fruits, setFruits] = useState(Fruits)
    const [veggies, setVeggies] = useState(Veggies)

    const [userGroups, setUserGroups] = useState(_UserGroups)
    const [assignedUserGroups, setAssignedUserGroups] = useState([])
    const [hoveredRow, setHoveredRow] = useState(null)

    const rowStyles = {

    }


    const userGroupRows = userGroups.map((userGroup =>
        <tr
            onClick={() => assignGroup(userGroup)} key={userGroup.GROUP_ID}
            onMouseEnter={()=>setHoveredRow(userGroup.GROUP_ID)}
            onMouseLeave={()=>setHoveredRow(null)}
            style={{
                backgroundColor: hoveredRow === userGroup.GROUP_ID ?"#f0f0f0":"transparent",
                border:"1px solid #ddd",
            }}
        >
            <td>{userGroup.GROUP_ID}</td>
            <td>{userGroup.GROUP_NAME}</td>
        </tr>))

    const assignedGroupRows = assignedUserGroups.map((assignedUserGroup =>
        <tr
            onClick={() => unassignGroup(assignedUserGroup)} key={assignedUserGroup.GROUP_ID}
            onMouseEnter={()=>setHoveredRow(assignedUserGroup.GROUP_ID)}
            onMouseLeave={()=>setHoveredRow(null)}
            style={{
                backgroundColor: hoveredRow === assignedUserGroup.GROUP_ID ?"#f0f0f0":"transparent",
                border:"1px solid #ddd",
            }}
        >
            <td>{assignedUserGroup.GROUP_ID}</td>
            <td>{assignedUserGroup.GROUP_NAME}</td>
        </tr>))



    function handleSwitch(removedItem) {
        console.log(removedItem)
        console.log(fruits.filter((fruit, i) => fruit.id !== removedItem.id))
        setFruits(fruits.filter((fruit, i) => fruit.id !== removedItem.id))
        setVeggies(v => [...v, removedItem])
    }


    function assignGroup(assignedGroup) {
        const exists = assignedUserGroups.map((assigned => assigned.GROUP_ID === assignedGroup.GROUP_ID))

        if (exists.every((x => x === false))) {
            setAssignedUserGroups(g => [...g, assignedGroup])
        }
    }

    function handleHover() {
        console.log('hovered')
    }

    function unassignGroup(unassignedGroup) {
        setAssignedUserGroups(assignedUserGroups.filter((group => group.GROUP_ID !== unassignedGroup.GROUP_ID)))
    }

    return (
        <>
            <Grid2 container spacing={4}>
                <Grid2 xs={6}>
                    <h6>User Groups</h6>
                    <table>
                        <thead>
                            <tr><td>ID</td><td>Name</td>{/*<td>Calories</td>*/}</tr>
                        </thead>
                        <tbody>
                            {userGroupRows}
                        </tbody>
                    </table>
                </Grid2>
                <Grid2 xs={6}>
                    <h6>Assigned Groups</h6>
                    <table>
                        <thead>
                            <tr><td>ID</td><td>Name</td></tr>
                        </thead>
                        <tbody>
                            {assignedGroupRows}
                        </tbody>
                    </table>
                </Grid2>
            </Grid2>
            {/* <Controls.Button variant='outlined'></Controls.Button> */}
            {/* <Controls.Button>Save</Controls.Button> */}
            <Box textAlign='center'>
                <Button variant="outlined">Save</Button>
            </Box>
        </>
    )
}

export default FruitOperations