import { Grid, Grid2, Paper } from "@mui/material"
import Box from '@mui/material/Box'
import { red } from "@mui/material/colors"

function Layouts() {
    return (
        // <>
        //     <Box>
        //         <Grid2 sx={{ backgroundColor: "#888" }} container spacing={0.5}>
        //             <Grid2
        //                 size={{ md: 4 }}
        //                 sx={{ backgroundColor: "#7451f8", textAlign: "right" }}
        //             >
        //                 White background
        //             </Grid2>
        //             <Grid2 size={{ md: 8 }} sx={{ backgroundColor: "red" }}>
        //                 Other background
        //             </Grid2>
        //         </Grid2>
        //     </Box>
        //     <Grid2 spacing={2} justifyContent="flex-end" container>
        //         <Grid2 size={{ xs: 0.5, md: 0.5 }}>
        //             <Paper sx={{ backgroundColor: "green", height: 600 }} elevation={5} />
        //         </Grid2>

        //     </Grid2>
        //     <Grid2 container justifyContent='flex-start' >

        //     </Grid2>
        //     <Box justifyContent='flex-end' xs={6}>
        //         <Grid2 >
        //             <Paper
        //                 sx={{ backgroundColor: "purple", height: 600 }}
        //                 elevation={5}
        //             />
        //         </Grid2>
        //         <Grid2>
        //             <Paper
        //                 sx={{ backgroundColor: "pink", height: 600 }}
        //                 elevation={5}
        //             />
        //         </Grid2>

        //     </Box>
        // </>

        // <Box
        //     sx={{
        //         position: 'relative',
        //         width: '100vw',
        //         height: '100vh',
        //     }}
        // >
        //     {/* Top-Left Corner */}
        //     <Box
        //         sx={{
        //             position: 'absolute',
        //             top: { xs: '5px', sm: '10px' }, // Adjusts padding from top
        //             left: { xs: '5px', sm: '10px' }, // Adjusts padding from left
        //             width: { xs: '30px', sm: '40px', md: '50px' }, // Box width by screen size
        //             height: { xs: '30px', sm: '40px', md: '50px' }, // Box height by screen size
        //             backgroundColor: 'primary.main',
        //         }}
        //     />

        //     {/* Top-Right Corner */}
        //     <Box
        //         sx={{
        //             position: 'absolute',
        //             top: { xs: '5px', sm: '10px' }, // Adjusts padding from top
        //             right: { xs: '5px', sm: '10px' }, // Adjusts padding from right
        //             width: { xs: '30px', sm: '40px', md: '50px' },
        //             height: { xs: '30px', sm: '40px', md: '50px' },
        //             backgroundColor: 'secondary.main',
        //         }}
        //     />

        //     {/* Bottom-Left Corner */}
        //     <Box
        //         sx={{
        //             position: 'absolute',
        //             bottom: { xs: '5px', sm: '10px' }, // Adjusts padding from bottom
        //             left: { xs: '5px', sm: '10px' }, // Adjusts padding from left
        //             width: { xs: '30px', sm: '40px', md: '50px' },
        //             height: { xs: '30px', sm: '40px', md: '50px' },
        //             backgroundColor: 'error.main',
        //         }}
        //     />

        //     {/* Bottom-Right Corner */}
        //     <Box
        //         sx={{
        //             position: 'absolute',
        //             bottom: { xs: '5px', sm: '10px' }, // Adjusts padding from bottom
        //             right: { xs: '5px', sm: '10px' }, // Adjusts padding from right
        //             width: { xs: '30px', sm: '40px', md: '50px' },
        //             height: { xs: '30px', sm: '40px', md: '50px' },
        //             backgroundColor: 'success.main',
        //         }}
        //     />
        // </Box>

        <>
            <Box component='section'>
                <Paper sx={{ backgroundColor: 'green', height: 200 }} size={{ lg: 6 }} elevation={5}>

                </Paper>
                <Paper sx={{ backgroundColor: 'gold', height: 200 }} size={{ xs: 2 }} elevation={5}>

                </Paper>
                <Paper sx={{ backgroundColor: 'red', height: 200 }} size={{ xs: 2 }} elevation={5}>

                </Paper>
            </Box>
        </>
    )
}
export default Layouts