import React, { useState } from "react";

const FormWithTabs = () => {
 const [formData, setFormData] = useState({
   firstName: "",
   surname: "",
   department: "",
 });

 const [activeTab, setActiveTab] = useState("Report1");

 const handleInputChange = (e) => {
   const { name, value } = e.target;
   setFormData((prev) => ({ ...prev, [name]: value }));
 };

 const handleTabChange = (tab) => {
   setActiveTab(tab);
 };

 return (
   <div style={containerStyle}>
     {/* Form Section */}
     <div style={formSectionStyle}>
       <h2 style={headingStyle}>Record Details</h2>
       <form style={formStyle}>
         <label style={labelStyle}>
           First Name:
           <input
             type="text"
             name="firstName"
             value={formData.firstName}
             onChange={handleInputChange}
             style={inputStyle}
           />
         </label>
         <label style={labelStyle}>
           Surname:
           <input
             type="text"
             name="surname"
             value={formData.surname}
             onChange={handleInputChange}
             style={inputStyle}
           />
         </label>
         <label style={labelStyle}>
           Department:
           <select
             name="department"
             value={formData.department}
             onChange={handleInputChange}
             style={inputStyle}
           >
             <option value="">Select Department</option>
             <option value="HR">HR</option>
             <option value="Engineering">Engineering</option>
             <option value="Marketing">Marketing</option>
           </select>
         </label>
       </form>
     </div>

     {/* Tab Section */}
     <div style={tabSectionStyle}>
       <div style={tabNavStyle}>
         {["Report1", "Report2", "Report3"].map((tab) => (
           <button
             key={tab}
             onClick={() => handleTabChange(tab)}
             style={{
               ...tabStyle,
               ...(activeTab === tab ? activeTabStyle : {}),
             }}
           >
             {tab}
           </button>
         ))}
       </div>
       <div style={tabContentStyle}>
         {activeTab === "Report1" && <p>Assign reports related to financials.</p>}
         {activeTab === "Report2" && <p>Assign reports related to operations.</p>}
         {activeTab === "Report3" && <p>Assign reports related to strategy.</p>}
       </div>
     </div>
   </div>
 );
};

/* Inline Styles */
const containerStyle = {
 fontFamily: "'Arial', sans-serif",
 margin: "20px auto",
 maxWidth: "600px",
 border: "1px solid #ddd",
 borderRadius: "8px",
 overflow: "hidden",
 boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
};

const formSectionStyle = {
 padding: "20px",
 backgroundColor: "#f9f9f9",
};

const formStyle = {
 display: "flex",
 flexDirection: "column",
 gap: "15px",
};

const labelStyle = {
 display: "flex",
 flexDirection: "column",
 fontSize: "14px",
 fontWeight: "bold",
 color: "#333",
};

const inputStyle = {
 padding: "8px",
 marginTop: "5px",
 border: "1px solid #ddd",
 borderRadius: "4px",
 fontSize: "14px",
};

const headingStyle = {
 marginBottom: "15px",
 fontSize: "18px",
 color: "#444",
};

const tabSectionStyle = {
 padding: "20px",
};

const tabNavStyle = {
 display: "flex",
 gap: "10px",
 marginBottom: "15px",
};

const tabStyle = {
 padding: "8px 15px",
 border: "1px solid #ddd",
 borderRadius: "4px",
 backgroundColor: "#f0f0f0",
 cursor: "pointer",
 fontSize: "14px",
};

const activeTabStyle = {
 backgroundColor: "#007BFF",
 color: "#fff",
 border: "1px solid #0056b3",
};

const tabContentStyle = {
 padding: "10px",
 border: "1px solid #ddd",
 borderRadius: "4px",
 backgroundColor: "#fafafa",
};

export default FormWithTabs;