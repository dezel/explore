function FruitList({fruits}) {

    const clicked=(data)=>{
        console.log(fruits)
    }
    const tableRows = fruits.map((fruit => <tr onClick={()=>clicked(fruit)} key={fruit.id}><td>{fruit.name}</td><td>{fruit.calories}</td></tr>));
    return (
        <table><tbody>{tableRows}</tbody></table>
    )
}

export default FruitList