import Popup from "./Popup";
import { styled } from "@mui/material/styles";
import useTable from "./useTable";
import {
    TableBody,
    TableRow,
    TableCell,
    Toolbar,
    InputAdornment,
    Button,
    TextField,
} from "@mui/material";

import { tableCellClasses } from "@mui/material/TableCell";
import { useState } from "react";
import SearchForm from "./SearchForm";
import { userRequest } from "./requestMethod";
import SearchIcon from './magnifier.svg'
import RegisterReport from "./RegisterReport";
import Loader from "./Loader";
import { ReactComponent as LockIcon } from "./lock.svg";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.body}`]: {
        fontSize: 15,
        fontWeight: "300",
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:hover": {
        backgroundColor: "#fffbf2",
        cursor: "pointer",
    },
}));

// INITIALIZE TABLE HEAD INFO
const headCells = [
    { id: "report_id", label: "Report ID" },
    { id: "report_name", label: "Report Name" },
    { id: "folder", label: "Folder" }
];

const btnPrimary = {
    minWidth: 0,
    margin: "3px",
    backgroundColor: "#3c44b126",
    color: "#333996",
};

const btnSecondary = {
    minWidth: 0,
    margin: "3px",
    backgroundColor: " #f8324526",
    color: "#f83245",
};

const FormEdit = ({ EditForm }) => {
    const [denyPopup, setDenyPopup] = useState(false)
    const [editPopup, setEditPopup] = useState(false)

    const [searchString, setSearchString] = useState('')
    const [reports, setReports] = useState()
    const [report, setReport] = useState()
    const [loading, setLoading] = useState(false)



    const searchUser = (e) => {
        e.preventDefault()
        setLoading(true)

        userRequest.post('/search_report', { searchString: searchString })
            .then((res) => {
                setReports(res.data)
                // console.log(res.data)
                setLoading(false)

            }).catch((err) => {
                console.log(err)
                setLoading(false)

            })
    }

    const { TblContainer, TblHead } =
        useTable(reports ? setReports : {});


    return (
        <>
            <TextField
                variant="standard"
                sx={{
                    marginBottom: 5,
                    marginLeft: 3
                }}
                onChange={(e) => setSearchString(e.target.value)}
            // label="User ID"
            >
            </TextField>
            <Button variant="primary" color="primary" onClick={searchUser}>
                <img src={SearchIcon} alt=""
                    style={{
                        justifyContent: 'center',
                        alignItems: 'center',
                        display: 'flex',
                        height: '20px',
                        width: '20px',
                        margin: '0px'
                    }}
                ></img>Search</Button>
            {
                reports ?
                    <>
                        <TblContainer>
                            <TblHead headCells={headCells} />
                            <TableBody>
                                {reports.map((report) => (
                                    <StyledTableRow
                                        key={report.REPORT_ID}
                                    >
                                        <StyledTableCell>{report.REPORT_ID}</StyledTableCell>
                                        <StyledTableCell>{report.REPORT_NAME}</StyledTableCell>
                                        <StyledTableCell>{report.FOLDER}</StyledTableCell>
                                        <StyledTableCell>
                                            {
                                                EditForm ?
                                                    <>
                                                        <Button
                                                            style={btnPrimary}
                                                            onClick={() => {
                                                                setEditPopup(true)
                                                                setReport(report)
                                                            }
                                                            }
                                                        >
                                                            Edit
                                                        </Button>

                                                    </>
                                                    :
                                                    <>
                                                        <Button
                                                            style={btnPrimary}
                                                            onClick={() => {
                                                                setDenyPopup(true)
                                                                console.log(report)
                                                            }}
                                                        >
                                                            Open
                                                        </Button>

                                                        <Popup setOpenPopup={setDenyPopup} openPopup={denyPopup} title={"Deny User Report"}>
                                                            <RegisterReport Report={report} Edit={true} />
                                                        </Popup>
                                                    </>
                                            }
                                        </StyledTableCell>
                                    </StyledTableRow>
                                ))}
                            </TableBody>
                        </TblContainer>
                        <Popup setOpenPopup={setEditPopup} openPopup={editPopup}
                            title={"Edit Report"}>
                            <RegisterReport
                                Report={report}
                                Edit={true}
                            />
                        </Popup>

                    </>
                    :
                    <>
                    </>
            }
            <Loader isLoading={loading} />
        </>
    );
};

export default FormEdit;