import { Box, Paper, Typography, Grid2 } from "@mui/material"

const MenuItem = ({ title, Icon, onClick, backgroundColor }) => {
    return (
        <Paper
            onClick={onClick}
            sx={{
                padding: 2,
                textAlign: 'center',
                color: '#7c0b2b',
                border: '1px solid #7c0b2b',
                margin: 0.1,
                display: "flex",
                '&:hover': {
                    bgcolor: '#938ba1',
                    cursor: "pointer"
                },
                borderRadius: 0.5,
                bgcolor:backgroundColor,
                transition: "background-color 0.3s ease"
            }}
            elevation={8}
        >
            <Grid2 justifyContent={"center"} container >
                <img style={{height: 70, width: 70}}
                    src={Icon}
                />
                <h5 style={{margin:1}}>{title}</h5>
            </Grid2>

        </Paper>
    );
}

export default MenuItem