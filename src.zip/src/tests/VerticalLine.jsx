
const VerticalLine=()=>{
const containerStyle = {
    display: 'grid',
    gridTemplateColumns: '1fr 1px 1fr', // Two items and a column for the line
    alignItems: 'center',
    gap: '10px',
    height: '100px',
  };

  const itemStyle = {
    textAlign: 'center',
    backgroundColor: '#f0f0f0',
    padding: '20px',
    borderRadius: '5px',
  };

  const lineStyle = {
    backgroundColor: '#000', // Line color
    width: '1px', // Line thickness
    height: '100%', // Full height of the container
  };

  return (
    <div style={containerStyle}>
      <div style={itemStyle}>Item 1</div>
      <div style={lineStyle}></div>
      <div style={itemStyle}>Item 2</div>
    </div>
  );
}

export default VerticalLine
