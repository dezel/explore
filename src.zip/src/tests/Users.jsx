import { Box, Card, Paper, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import AddUserIcon from './add_user_icon.svg';
import Popup from "./Popup";
import UserManagement from "../forms/UserManagement";
import PaperNew from "./PaperNew";
import ReportIcon from './report_icon.svg'
import AssignReport from "./AssignReport";
import UserIcon from "./user_icon.svg";
import AddUser from "./AddUser";
import SearchForm from "./SearchForm";
import UserEdit from "./UserEdit";


const Users = ({
    openAddUser,
    setOpenAddUser,
    showDenyReport,
    setShowDenyReport,
    openEditUser,
    setEditUser,
    showAssignGroup,
    setShowAssignGroup,
    children }) => {


    return (
        <>
            <h3>Users</h3>
            <Box
                sx={{
                    margin: '10px',
                    border: "none",
                    padding: '10px',
                    flexDirection: 'row',
                    display: 'flex',
                    height: '100%'
                }}
            >
                {children}
                <PaperNew title='Add User' Icon={AddUserIcon} onClick={() => setOpenAddUser(true)} />
                <PaperNew onClick={() => setEditUser(true)} title="Edit User" Icon={UserIcon} />
                <PaperNew onClick={() => setShowDenyReport(true)} title="Deny Report" Icon={UserIcon} />
                {/* <PaperNew onClick={() => setShowAssignGroup(true)} title="Assign Group" Icon={UserIcon} /> */}
                
                <Popup
                    sx={{ minHeight: 600, width: 600, height: 600 }}
                    title={'Assign Group'}
                    openPopup={showAssignGroup}
                    setOpenPopup={setShowAssignGroup}>
                    <UserEdit EditUser={true} GroupAssign={true}/>
                </Popup>

                <Popup
                    sx={{ minHeight: 600, width: 600, height: 600 }}
                    title={'Add User'}
                    openPopup={openAddUser}
                    setOpenPopup={setOpenAddUser}>
                    <AddUser />
                </Popup>
                <Popup
                    sx={{ minHeight: 800, width: 600, height: 600 }}
                    title={'Deny Report Access'}
                    setOpenPopup={setShowDenyReport}
                    openPopup={showDenyReport}
                >
                    <UserEdit />
                </Popup>

                <Popup
                    sx={{ minHeight: 800, width: 600, height: 600 }}
                    title={'Edit User'}
                    setOpenPopup={setEditUser}
                    openPopup={openEditUser}
                >
                    <UserEdit EditUser={true} />
                </Popup>

            </Box>
        </>
    )
}

export default Users;