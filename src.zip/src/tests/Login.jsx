import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Box, Link, InputAdornment } from '@mui/material';
import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";
import { userRequest } from './requestMethod';
import "./Login.css";
import Banner from "../tests/fidelity_logo.png"
import Loading from './loader.svg'
import Loader from './Loader';
import { ReactComponent as LockIcon } from "./lock.svg";
import { ReactComponent as UserIcon } from "./user.svg";


const Login = () => {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const [wrongPassword, setWrongPassword] = useState(false)
    const [errorMessage, setErrorMessage] = useState('')
    const [loading, setLoading] = useState(false)

    const handleSignIn = (event) => {
        event.preventDefault();
        setLoading(true)
        userRequest.post('/login', { username, password })
            .then((res) => {

                if (res.data.is_auth) {
                    navigate('/home/home')
                }
                localStorage.setItem('userData', JSON.stringify(res.data))
                setLoading(false)
            })
            .catch((err) => {
                console.log(err)
                setWrongPassword(true)
                setUsername('')
                setPassword('')
                setLoading(false)
            })
    };

    const navigate = useNavigate();
    localStorage.clear()
    return (
        <div className='login-container'>
            <Container
                maxWidth="xs"
                sx={{
                    justifyContent: 'center'
                }}
            >
                <div style={{
                    justifyContent: 'center'
                }}>
                    <img
                        style={{
                            alignItems: 'center',
                            alignContent: 'center',
                            width: '100%', height: 100,
                            marginTop: -30,
                            alignContent: 'left'
                        }}
                        src={Banner}
                    />
                </div>
                <Box
                    sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        mt: 8,
                        boxShadow: 3,
                        p: 4,
                        borderRadius: 2,
                        backgroundColor: 'white',
                    }}
                >
                    <Typography variant="h4" gutterBottom>
                        Sign In
                    </Typography>
                    <Box component="form" onSubmit={handleSignIn} sx={{ mt: 1, width: '100%' }}>
                        <TextField
                            label="Username"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            required
                            value={username}
                            sx={wrongPassword ? { border: '2px solid red', borderRadius: '5px' } : {}}
                            // InputProps={{
                            //     endAdornment: (
                            //         <InputAdornment position="end">
                            //             <UserIcon style={{ width: 20, height: 20 }} />
                            //         </InputAdornment>
                            //     ),
                            // }}
                            slotProps={{
                                input: {
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <UserIcon style={{ width: 20, height: 20 }} />
                                        </InputAdornment>
                                    ),
                                },
                            }}
                            onChange={(e) => setUsername(e.target.value)}
                        />
                        <TextField
                            label="Password"
                            type="password"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            required
                            value={password}
                            sx={wrongPassword ? { border: '2px solid red', borderRadius: '5px' } : {}}
                            slotProps={{
                                input: {
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <LockIcon style={{ width: 20, height: 20 }} />
                                        </InputAdornment>
                                    ),
                                },
                            }}
                            onChange={(e) => setPassword(e.target.value)}
                        />{
                            wrongPassword ?
                                <div style={{ color: 'red' }}>Username or password is wrong</div>
                                :
                                <div></div>
                        }
                        <Loader isLoading={loading} />
                        <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            fullWidth
                            sx={{ mt: 2, mb: 2 }}
                            onClick={handleSignIn}
                        >
                            Sign In
                        </Button>
                    </Box>
                </Box>

            </Container>
        </div>
    );
};

export default Login;