import { Box, Card, Paper, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import Tile from "./Tile";

const Home = ({children }) => {


    return (
        <Box
            sx={{
                margin: '10px',
                border: "none",
                padding: '10px',
                flexDirection: 'row',
                display: 'flex',
                height: '100%'
            }}
        >
            {children}
        </Box>
    )
}

export default Home;