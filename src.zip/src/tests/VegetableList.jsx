import Veggies from "./Veggies";

function VegetableList({Veggies}) {

    console.log(Veggies)
    
    const clicked=(data)=>{
        console.log(data)
        console.log('clicked')
        Veggies.pop()

        setFoods(foods.filter((_, i) => i !== index));
    }
    const tableRows = Veggies.map((vegetable => <tr onClick={()=>clicked(vegetable)} key={vegetable.id}><td>{vegetable.name}</td><td>{vegetable.calories}</td></tr>));
    return (
        <table><tbody>{tableRows}</tbody></table>
    )
}

export default VegetableList