import { Box  } from "@mui/material";
import Popup from "./Popup";
import PaperNew from "./PaperNew";
import ReportIcon from './report_icon.svg'
import AddGroup from "./AddGroup";
import SearchForm from "./SearchForm";
import GroupIcon from "./group_icon.svg"



const Groups = ({
    openAddGroup,
    setOpenAddGroup,
    openAssignReportPopup,
    setOpenAssignReportPopup,
    children }) => {
    return (
        <>
            <h3>Groups</h3>
            <Box
                sx={{
                    margin: '10px',
                    border: "none",
                    padding: '10px',
                    flexDirection: 'row',
                    display: 'flex',
                    height: '100%'
                }}
            >
                {children}
                <PaperNew title="Add Group" Icon={GroupIcon} onClick={() => setOpenAddGroup(true)} />
                <Popup
                    sx={{ minHeight: 600, width: 600, height: 600 }}
                    title={'Add group'}
                    openPopup={openAddGroup}
                    setOpenPopup={setOpenAddGroup}>
                    <AddGroup />
                </Popup>
                {/* <PaperNew Icon={UserIcon} /> */}
                {/* <Popup
                    title={'Add User'}
                >
                    <AddUser />
                </Popup> */}
                <PaperNew title={'Assign Report'} Icon={ReportIcon} onClick={(e) => setOpenAssignReportPopup(true)} />

                <Popup
                    sx={{ minHeight: 600, width: 600, height: 600 }}
                    title={'Assign Report'}
                    openPopup={openAssignReportPopup}
                    setOpenPopup={setOpenAssignReportPopup}>
                    {/* <AssignReport></AssignReport> */}
                    <SearchForm Group={true} />
                </Popup>

            </Box>
        </>
    )
}

export default Groups;