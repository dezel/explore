import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from "react-router-dom";
import { Grid2, Paper, Box, Typography, Button } from "@mui/material";
import Navbar from "../forms/Navbar";
import Users from "./Users";
import Groups from "./Groups";
import Reports from "./Reports";
import UserIcon from "./user_icon.svg";
import ReportIcon from './report_icon.svg';
import SettingsIcon from "./cog.svg";
import GroupIcon from "./group_icon.svg";
import HomeIcon from "./home.svg";
import Home from "./Home";
import Tile from "./Tile";

// Define the tabs and their paths
const tiles = [
    { label: "Home", path: "/home/home", icon: HomeIcon },
    { label: "Users", path: "/home/users", icon: UserIcon },
    { label: "Groups", path: "/home/groups", icon: GroupIcon },
    { label: "Reports", path: "/home/reports", icon: ReportIcon },
    { label: "Settings", path: "/home/settings", icon: SettingsIcon },
];

// Component for each tab (tile)
const TileTab = ({ label, path, isActive, Icon }) => (
    <Paper
        component={Link}
        to={path}
        elevation={2}
        sx={{
            cursor: "pointer",
            padding: 2,
            margin: "8px 0",
            textAlign: "center",
            textDecoration: "none",
            color: "inherit",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height: 60,
            backgroundColor: isActive ? "#fc831a" : "white",
            border: '1px solid',
            color: '#7c0b2b',
            transition: "background-color 0.3s ease",
            "&:hover": {
                backgroundColor: "#fc831a",
            },
        }}
    >
        <img style={{ height: 70, width: 70 }}
            src={Icon}
        />
        <Typography variant="h4" sx={{ fontSize: "1rem", color: isActive ? 'black' : 'grey', fontWeight: isActive ? 'bold' : '' }}>
            {label}
        </Typography>
    </Paper>
);

// Page components for each route
const Page = ({ title, content }) => (
    <Box
        sx={{
            padding: 4,
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
        }}
    >
        <Typography variant="h4" gutterBottom>
            {title}
        </Typography>
        <Typography sx={{ marginBottom: 2 }}>{content}</Typography>
        <Button variant="contained" color="primary">
            Explore More
        </Button>
    </Box>
);

// Main application layout
const HomePage = () => {
    const location = useLocation(); // Get the current path
    const [showGroups, setShowGroups] = useState(false);
    const [openEditUser, setOpenEditUser] = useState(false)
    const [showAddUser, setAddUser] = useState(false);
    const [openAssignReportPopup, setOpenAssignReportPopup] = useState(false);
    const [showRegisterReport, setShowRegisterReport] = useState(false);
    const [showDenyReport, setShowDenyReport] = useState(false);
    const [showEditReport, setShowEditReport] = useState(false)
    const [showAssignGroup, setShowAssignGroup] = useState(false)

    return (
        <>
            <Navbar />
            <Box sx={{transition: "background-color 10s ease",display: "flex", height: "100vh", overflow: "hidden" }}>
                {/* Left panel with vertical tabs */}
                <Grid2
                    xs={3}
                    sx={{
                        borderRight: "1px solid #ccc",
                        padding: 2,
                        height: "100%",
                        overflowY: "auto",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                    }}
                >
                    {tiles.map((tile, index) => (
                        <TileTab
                            key={index}
                            label={tile.label}
                            path={tile.path}
                            isActive={location.pathname === tile.path} // Highlight if current route matches
                            Icon={tile.icon}
                        />
                    ))}
                </Grid2>

                {/* Right panel for dynamic content */}
                <Grid2
                    xs={9}
                    sx={{
                        padding: 4,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexDirection: "column",
                    }}
                >
                    <Routes>
                        <Route
                            path="/home"
                            // element={<Page title="Home" content="Welcome to the Home Page!" />}
                        element={<Home>
                            </Home>
                            }
                        />
                        <Route
                            path="/users"
                            element={
                                <Users openAddUser={showAddUser}
                                    setOpenAddUser={setAddUser}
                                    showDenyReport={showDenyReport}
                                    setShowDenyReport={setShowDenyReport}
                                    openEditUser={openEditUser}
                                    setEditUser={setOpenEditUser}
                                    setShowAssignGroup={setShowAssignGroup}
                                    showAssignGroup={showAssignGroup}
                                />
                            }
                        />
                        <Route
                            path="/groups"
                            element={<Groups openAddGroup={showGroups}
                                setOpenAddGroup={setShowGroups}
                                openAssignReportPopup={openAssignReportPopup}
                                setOpenAssignReportPopup={setOpenAssignReportPopup}
                            />}
                        />
                        <Route
                            path="/reports"
                            element={<Reports
                                showRegisterReport={showRegisterReport}
                                setShowRegisterReport={setShowRegisterReport}
                                showEditReport={showEditReport}
                                setShowEditReport={setShowEditReport}
                            />}
                        />
                        {/* <Route
                            path="/settings"
                            element={<Settings />}
                        /> */}
                    </Routes>
                </Grid2>
            </Box>
        </>
    );
};
export default HomePage;