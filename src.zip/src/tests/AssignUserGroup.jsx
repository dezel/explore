import React, { useEffect, useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import Paper from "@mui/material/Paper";
import { userRequest } from "./requestMethod";
import { MenuItem, Select,InputAdornment } from "@mui/material";
import CloseButton from './close-button-icon.svg'
import ConfirmationDialog from "./ConfirmationDialog";
import { ReactComponent as LockIcon } from "./lock.svg";

const AssignUserGroup = ({ Deny, Group, User }) => {
    // const [userAssigned, setUserAssigned] = useState(User)
    const [selectedResult, setSelectedResult] = useState([]);
    const [groups, setGroups] = useState([])
    const [reports, setReports] = useState([])
    const [searchString, setSearchString] = useState('')
    const [selectedGroup, setSelectedGroup] = useState('')
    const user = JSON.parse(localStorage.getItem('userData'))
    const [confirmation, setConfirmation] = useState(false)
    const [message, setMessage] = useState('')
    const [title, setTitle] = useState('')
    const [showGroups, setShowGroups] = useState(false)

    // console.log(`to be unassigned ${userAssigned}`)
    // console.log(userAssigned)
    const getGroups = async () => {
        await userRequest.post('/get_groups')
            .then((res) => {
                setGroups(res.data)
                // console.log(res.data)
            }
            )
    }

    const getUserGroups = async () => {

        userRequest.post('/get_user_groups', { username: User.USER_ID })
            .then((res) => {
                // setGroups(res.data)
                // console.log(groups)
                setSelectedResult(res.data)
            }
            ).catch((err) => console.log(err))



        // console.log(User.groups)
    }
    // useEffect(() => {
    //     setSelectedResult(User?User.groups:[])
    // }, []
    // )
    const getUsers = async () => {
        await userRequest.post('/get_groups')
            .then((res) => {
                setGroups(res.data)
                console.log(res.data)
            }
            )
    }


    useEffect(() => {
        // Group ? getGroups() : getUsers()
        getGroups()
        getUserGroups()
    }, [])


    const handleAssign = () => {
        console.log(selectedResult)
        console.log(selectedGroup)

        const individualFormData = {
            username: User.USER_ID,
            groups: selectedResult

        }

        const groupFormData = {
            group: {
                group_id: selectedGroup,
                reports: selectedResult
            }
        }
        console.log(groupFormData)

        if (Group) {
            userRequest.post('/assign_report_group', groupFormData)
                .then((res) => console.log(res))
                .then(
                    setSelectedResult([])
                )
        } else {
            console.log(individualFormData)
            userRequest.post('/assign_user_group', individualFormData)
                .then((res) => console.log(res))
                .then(() => {
                    setSelectedResult([])
                    setMessage('User group updated successfully')
                    setTitle('Success')
                    setConfirmation(true)
                })
                .catch((res) => {
                    setMessage('User group update failed')
                    setTitle('Failed')
                    setConfirmation(true)
                })
        }
    }

    const handleDeny = () => {
        console.log(selectedResult)
        console.log(selectedGroup)

        if (Group) {

        }
        else {
            const individualFormData = {
                user: { USER_ID: User.USER_ID, REPORT_ID: selectedResult }
            }
            console.log(individualFormData)

            userRequest.post('/deny_report_individual', individualFormData)
                .then((res) => {
                    setMessage('Report access updated successfully')
                    setTitle('Success')
                    setConfirmation(true)
                })
                .catch((res) => {
                    setMessage('Report update failed')
                    setTitle('Failed')
                    setConfirmation(true)
                    console.log(res)
                })
        }

    }


    const handleGroupChange = (event) => {
        const { name, value, key } = event.target
        console.log(value)
        setSelectedGroup(value)
        const postData = { group_id: value }
        // console.log(postData)
        setSelectedResult([])
        userRequest.post('/get_group_report', postData)
            .then((res) => {
                console.log(res.data)
                setSelectedResult(res.data)
            }
            )
    }

    const handleIndividualChange = (event) => {
        const { name, value, key } = event.target
        console.log(value)
        setSelectedGroup(value)
        const postData = { group_id: value }
        setSelectedResult([])
        userRequest.post('/get_group_report', postData)
            .then((res) => {
                console.log(res.data)
                setSelectedResult(res.data)
            })
    }


    const handleGroupUnassign = (unassignedReport) => {
        console.log('unassigned', unassignedReport)
        console.log(selectedResult)
        setSelectedResult(selectedResult.filter((result) => result.GROUP_ID !== unassignedReport.GROUP_ID))
        console.log(selectedResult)

    }


    const handleResultClick = (result, event) => {
        setShowGroups(false)
        if (!(selectedResult.some(x => x.GROUP_ID === result.GROUP_ID))) {
            setSelectedResult(r => [...r, result])
        }
    };
    // console.log(userAssigned)
    return (
        <Box
            component='form'
            onSubmit={Deny ? handleDeny : handleAssign}
            sx={{ maxHeight: 800, maxWidth: 500, width: 500, margin: "0 auto", textAlign: "center", position: "relative", fontSize: 14 }}>
            {
                Group ? <Select
                    fullWidth
                    // defaultValue="Please select group"
                    onChange={handleGroupChange}
                    label="Select Group"
                    sx={{ fontSize: 14, padding: 1 }}
                    defaultValue=""
                >
                    {
                        groups.map((group) => <MenuItem sx={{ fontSize: 14, padding: 1 }} key={group.GROUP_ID} value={group.GROUP_ID} >{group.GROUP_NAME}</MenuItem>)
                    }
                </Select> :
                    <TextField
                    slotProps={{
                        input: {
                            readOnly: true,

                            endAdornment: (
                                <InputAdornment position="end">
                                    {<LockIcon style={{ width: 20, height: 20 }} />}
                                </InputAdornment>
                            )
                        }
                    }}
                        value={User.USER_ID}>
                    </TextField>
            }
            <TextField
                label="Search group"
                variant="standard"
                // inputprops={{ style: { fontSize: 14 } }}
                // onChange={searchReports}
                onClick={() => setShowGroups(true)}
                fullWidth
                margin="normal"
            // value={searchString}
            />
            {showGroups && (
                <Paper
                    sx={{
                        position: "fixed", // Ensure the results float above all content
                        top: "32%", // Adjust as needed for vertical placement
                        left: "50%", // Center horizontally
                        transform: "translateX(-50%)", // Adjust horizontal centering
                        zIndex: 1000, // High z-index to float above other elements
                        maxHeight: 200,
                        width: "32%", // Adjust width as needed
                        overflowY: "auto",
                        border: "1px solid #ccc",
                        borderRadius: 2,
                        backgroundColor: "white",
                        fontSize: 10,
                        '&:hover': {
                            cursor: 'pointer',
                        },
                        // display:{true}
                    }}

                    elevation={3}

                >
                    <List inputprops={{
                        style: {
                            fontSize: 14,
                            '&:hover': {
                                backgroundColor: 'grey',
                                cursor: 'pointer',
                            }
                        }
                    }}>
                        {groups.map((group) => (
                            <ListItem inputprops={{
                                style: {
                                    fontSize: 14, '&:hover': {
                                        backgroundColor: 'grey',
                                        cursor: 'pointer',
                                    }
                                }
                            }
                            } key={group.GROUP_ID} onClick={(e) => handleResultClick(group, e)}>
                                <Box sx={{
                                    fontSize: 14
                                }}>{group.GROUP_NAME}</Box>
                            </ListItem>
                        ))}
                    </List>
                </Paper>
            )}

            <Box sx={{
                overflow: "scroll",
                height: 100,
                minHeight: 150,
                width: '100%',
                marginTop: 2,
                marginBottom: 2,
                padding: 1,
                border: "1px solid #ccc",
                borderRadius: 2
            }}>
                {
                    selectedResult.map(result => (
                        <ListItem sx={{
                            '&:hover': {
                                backgroundColor: '#d4d2d2',
                                cursor: 'pointer'
                            }
                        }}
                            key={result.GROUP_ID}>
                            {result.GROUP_NAME}
                            <img onClick={() => handleGroupUnassign(result)}
                                style={{ width: 15, height: 15 }}
                                alt=""
                                src={CloseButton}>
                            </img>
                        </ListItem>))
                }
            </Box>
            <Button
                variant="contained"
                color="primary"
                onClick={Deny ? handleDeny : handleAssign}
                fullWidth
            >
                {Deny ? 'Deny' : 'Assign'}
            </Button>
            {confirmation &&
                <ConfirmationDialog
                    message={message}
                    onConfirm={() => {
                        setConfirmation(false)
                        // setFormData('')
                    }}
                    title={title}
                />
            }
        </Box>
    );
};

export default AssignUserGroup;
