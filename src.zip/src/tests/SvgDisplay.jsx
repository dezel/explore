import React from 'react';

function SvgDisplay({ svgIcon, size = 100 }) {
  return (
    <div
      style={{
        width: size,
        height: size,
      }}
    >
      {svgIcon}
    </div>
  );
}

export default SvgDisplay;
