body {
    margin: 0;
    font-family: 'Arial', sans-serif;
    background-color: #f5f5f5;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  .signin-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
  }
  
  .signin-form {
    background: #ffffff;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
  }
  
  .signin-title {
    margin-bottom: 1.5rem;
    font-size: 1.8rem;
    text-align: center;
    color: #333333;
  }
  
  .form-group {
    margin-bottom: 1rem;
  }
  
  .form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-size: 0.9rem;
    color: #555555;
  }
  
  .form-group input {
    width: 100%;
    padding: 0.8rem;
    border: 1px solid #cccccc;
    border-radius: 5px;
    font-size: 1rem;
  }
  
  .form-group input:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 3px rgba(0, 123, 255, 0.5);
  }
  
  .signin-button {
    width: 100%;
    padding: 0.8rem;
    font-size: 1rem;
    color: #ffffff;
    background-color: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  .signin-button:hover {
    background-color: #0056b3;
  }
  
  .signin-footer {
    margin-top: 1rem;
    text-align: center;
    font-size: 0.9rem;
  }
  
  .signin-footer a {
    color: #007bff;
    text-decoration: none;
  }
  
  .signin-footer a:hover {
    text-decoration: underline;
  }