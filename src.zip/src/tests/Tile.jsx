import { Paper } from "@mui/material";
import { Grid2 } from "@mui/material"
function Tile({ title, measure, count }) {
    measure = 'AC TRANSACTIONS REVISED 2'
    count = '18012'
    return (
        <Paper
            elevation={10}
            sx={{
                backgroundColor: 'white',
                height: 200,
                width: 200,
                // '&:hover': {
                //     backgroundColor: '#fc831a',
                //     cursor: 'pointer',
                // },
                display: "flex",
                justifyContent: "center",
                // alignItems: "center",
                margin: '15px',
                border: '1px solid',
                color: '#7c0b2b',
                transition: "background-color 0.3s ease",
                padding:1
            }}>
            <Grid2 sx={{justifyContent:'center'}}>
                <div style={{textAlign:'center', fontWeight:'bold', fontSize: 20, margin: 2 }}>Most Used Report</div>
                <div style={{textAlign:"center"}}>{measure}</div>
                <div style={{textAlign:'center'}}>{count}</div>
            </Grid2>
            {/* <div>Hi</div> */}
        </Paper>
    )
}

export default Tile;