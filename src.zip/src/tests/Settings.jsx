import { Box, Card, Paper, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import AddUserIcon from './add_user_icon.svg';
import Popup from "./Popup";
import UserManagement from "../forms/UserManagement";
import PaperNew from "./PaperNew";
import ReportIcon from './report_icon.svg'
import AssignReport from "./AssignReport";
import UserIcon from "./user_icon.svg";
import AddUser from "./AddUser";



const Settings = ({ 
    openAddReportPopup, 
    setOpenAddReport,

    children }) => {


    return (
        <Box
            sx={{
                margin: '10px',
                border: "none",
                padding: '10px',
                flexDirection: 'row',
                display: 'flex',
                height: '100%'
            }}
        >
            {children}
            <PaperNew Icon={ReportIcon} onClick={() => setOpenAddReport(true)} />
              
            <Popup
                sx={{ minHeight: 600,width: 600, height: 600 }}
                title={'Assign Report'}
                openPopup={openAddReportPopup}
                setOpenPopup={setOpenAddReport}>
                {/* <AssignReport></AssignReport> */}
                <UserManagement/>
            </Popup>

            <PaperNew Icon={UserIcon} />

            <Popup
                title={'Add User'}
            >
                <AddUser />
            </Popup>

        </Box>
    )
}

export default Settings;