// import React, {useState} from "react";
// import { Menu, MenuItem, Select } from "@mui/material";
import React, { useState } from "react";
import { Box, FormControl, InputLabel, MenuItem, Select } from "@mui/material";

const Selector = ({ options }) => {


    const [selectedValue, setSelectedValue] = useState("");

    const handleChange = (event) => {
        setSelectedValue(event.target.value);
        console.log(event.target.value)
    };

    return (
        <Box
            sx={{
                maxWidth: 300,
                margin: "20px auto",
                padding: 2,
                border: "1px solid #ccc",
                borderRadius: 2,
                minWidth: 100
            }}
        >
            <FormControl fullWidth>
                <InputLabel id="dropdown-label">Choose an Option</InputLabel>
                <Select
                    labelId="dropdown-label"
                    value={selectedValue}
                    onChange={handleChange}
                    label="Choose an Option"
                >
                    {options.map(
                        (option =>
                            <MenuItem value={option.REPORT_ID}>{option.REPORT_NAME}</MenuItem>))}
                </Select>
            </FormControl>
            {selectedValue && <p>Selected: {selectedValue}</p>}
        </Box>
    );
}

export default Selector;