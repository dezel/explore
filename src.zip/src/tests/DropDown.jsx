import React, { useState } from 'react';
import { Menu, MenuItem, Button, Typography } from '@mui/material';

function DropdownMenu() {
  const [anchorEl, setAnchorEl] = useState(null); // Track which menu is open
  const [submenuAnchorEl, setSubmenuAnchorEl] = useState(null); // Track submenu state
  const open = Boolean(anchorEl);
  const submenuOpen = Boolean(submenuAnchorEl);

  // Handle opening the main menu
  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  // Handle closing the main menu
  const handleMenuClose = () => {
    setAnchorEl(null);
    setSubmenuAnchorEl(null); // Close any open submenus
  };

  // Handle opening the submenu
  const handleSubmenuOpen = (event) => {
    setSubmenuAnchorEl(event.currentTarget);
  };

  // Handle closing the submenu
  const handleSubmenuClose = () => {
    setSubmenuAnchorEl(null);
  };

  return (
    <div>
      {/* Main Menu Button */}
      <Button
        variant="contained"
        onClick={handleMenuOpen}
        aria-controls={open ? 'main-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
      >
        Menu
      </Button>

      {/* Main Menu */}
      <Menu
        id="main-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleMenuClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button',
        }}
      >
        <MenuItem onClick={handleMenuClose}>Home</MenuItem>
        <MenuItem onClick={handleMenuClose}>About</MenuItem>

        {/* Submenu Trigger */}
        <MenuItem
          onMouseEnter={handleSubmenuOpen}
          onMouseLeave={handleSubmenuClose}
        >
          Services
        </MenuItem>

        {/* Submenu */}
        <Menu
          anchorEl={submenuAnchorEl}
          open={submenuOpen}
          onClose={handleSubmenuClose}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
        >
          <MenuItem onClick={handleMenuClose}>Service 1</MenuItem>
          <MenuItem onClick={handleMenuClose}>Service 2</MenuItem>
          <MenuItem onClick={handleMenuClose}>Service 3</MenuItem>
        </Menu>

        <MenuItem onClick={handleMenuClose}>Contact</MenuItem>
      </Menu>
    </div>
  );
}

export default DropdownMenu;