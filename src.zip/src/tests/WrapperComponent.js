import React from 'react';

function WrapperComponent({ Component, componentProps }) {
  return (
    <div style={{ border: '1px solid gray', padding: '20px' }}>
      {/* Dynamically render the passed component */}
      <Component {...componentProps} />
    </div>
  );
}

export default WrapperComponent;