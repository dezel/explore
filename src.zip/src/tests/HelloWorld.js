import React from 'react';
import WrapperComponent from './WrapperComponent';

// Example React components
function HelloWorld({ name }) {
  return <h1>Hello, {name}!</h1>;
}

function GoodbyeWorld({ farewellMessage }) {
  return <h1>{farewellMessage}</h1>;
}

function Renderer() {
  return (
    <div>
      {/* Pass HelloWorld component as a prop */}
      <WrapperComponent
        Component={HelloWorld}
        componentProps={{ name: 'Alice' }}
      />

      {/* Pass GoodbyeWorld component as a prop */}
      <WrapperComponent
        Component={GoodbyeWorld}
        componentProps={{ farewellMessage: 'Goodbye, Bob!' }}
      />
    </div>
  );
}

export default Renderer;