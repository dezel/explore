import Controls from "../controls/Controls";
import { FormControl, Grid2, Box, InputAdornment } from "@mui/material";
import { Button } from "@mui/material";
import { userRequest } from "./requestMethod";
import { useEffect, useState } from "react";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import InputLabel from "@mui/material/InputLabel";
import ConfirmationDialog from "./ConfirmationDialog";
import Loader from "./Loader";
import { ReactComponent as LockIcon } from "./lock.svg";


const RegisterReport = ({ Edit, Report }) => {
    const [confirmation, setConfirmation] = useState(false)
    const [message, setMessage] = useState('')
    const [title, setTitle] = useState('')
    const [loading, setLoading] = useState(false)
    const [user, setUser] = useState(JSON.parse(localStorage.getItem("userData")))

    useEffect(() => {
        setUser(JSON.parse(localStorage.getItem("userData")));
    }, [])

    const [formData, setFormData] = useState(
        {
            reportId: Report ? Report.REPORT_ID : "",
            reportName: Report ? Report.REPORT_NAME : "",
            folder: Report ? Report.FOLDER : "",
            description: Report ? Report.RPT_DESCRIPTION : "",
            status: Report ? Report.status : true,
            accessLevel: Report ? Report.RPT_ACCESS_LEVEL : "",
            mainSource: Report ? Report.MAIN_RPT_SOURCE_SYSTEM : "",
            unit: Report ? Report.AUTH_BUSINESS_UNIT : "",
            user: Report ? Report.AUTH_BUSINESS_USER : "",
            authorizer: Report ? Report.AUTH_BUSINESS_HEAD : "",
            createdBy: user ? user.username : ""
        }
    );

    const handleChange = (event) => {
        const { name, value, type, checked } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleSubmit = (e) => {
        setLoading(true)
        e.preventDefault();
        console.log(formData)
        if (Edit) {
            userRequest.post('/edit_report', formData)
                .then((res) => {
                    setMessage('Report added successfully')
                    setTitle('Success')
                    setConfirmation(true)
                    setLoading(false)
                })
                .catch((res) => {
                    setMessage('Report add failed')
                    setTitle('Failed')
                    setConfirmation(true)
                    setLoading(false)
                })
        }
        else {

            userRequest.post('register_report', formData)
                .then((res) => {
                    setMessage('Report added successfully')
                    setTitle('Success')
                    setConfirmation(true)
                    setLoading(false)

                })
                .then((res) => console.log(res))
                .catch((err) => {
                    setMessage('Report add failed')
                    setTitle('Failed')
                    setConfirmation(true)
                    setLoading(false)

                })
        }
    }

    return (
        <>
            <FormControl sx={{ minWidth: 300, width: 350 }}>
                <Grid2 spacing={4} size={{ xs: 12, md: 12 }} container>
                    {
                        Edit ?
                            <>
                                <Controls.Input
                                    sx={{ margin: 0 }}
                                    size="small"
                                    variant="standard"
                                    name="reportId"
                                    required
                                    onChange={handleChange}
                                    label="Report ID"
                                    fullWidth
                                    slotProps={{
                                        input: {
                                            readOnly: Edit,

                                            endAdornment: (
                                                <InputAdornment position="end">
                                                    {Edit ? <LockIcon style={{ width: 20, height: 20 }} /> : <></>}
                                                </InputAdornment>
                                            )
                                        }
                                    }}
                                    value={formData.reportId}
                                >
                                </Controls.Input>
                            </>
                            :
                            <>
                            </>
                    }
                    <Controls.Input
                        // sx={{ margin: 0 }}
                        size="small"
                        variant="standard"
                        name="reportName"
                        required
                        onChange={handleChange}
                        label="Report name"
                        fullWidth
                        value={formData.reportName}
                    ></Controls.Input>
                    <Controls.Input
                        // sx={{ padding: 0 }}
                        size="small"
                        variant="standard"
                        name="folder"
                        onChange={handleChange}
                        label="Folder"
                        fullWidth
                        required
                        value={formData.folder}
                    >
                    </Controls.Input>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="description"
                        onChange={handleChange}
                        label="Description"
                        fullWidth
                        required
                        value={formData.description}
                    ></Controls.Input>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="mainSource"
                        onChange={handleChange}
                        label="Main source"
                        fullWidth
                        required
                        value={formData.mainSource}
                    ></Controls.Input>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="unit"
                        onChange={handleChange}
                        label="Business Unit"
                        fullWidth
                        required
                        value={formData.unit}
                    ></Controls.Input>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="user"
                        onChange={handleChange}
                        label="Business User"
                        fullWidth
                        required
                        value={formData.user}
                    ></Controls.Input>
                    <Controls.Input
                        size="small"
                        variant="standard"
                        name="authorizer"
                        onChange={handleChange}
                        label="Authorizer"
                        fullWidth
                        required
                        value={formData.authorizer}
                    ></Controls.Input>

                    <FormControl fullWidth style={{ marginTop: "16px" }}>
                        <InputLabel id="select-label">Select access level</InputLabel>
                        <Select
                            labelId="select-label"
                            value={formData.accessLevel}
                            onChange={handleChange}
                            name="accessLevel"
                        >
                            <MenuItem value={1}>Level 1</MenuItem>
                            <MenuItem value={2}>Level 2</MenuItem>
                            <MenuItem value={3}>Level 3</MenuItem>
                            <MenuItem value={4}>Level 4</MenuItem>
                            <MenuItem value={5}>Level 5</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControlLabel
                        control={<Checkbox name='status' checked={formData.active} onChange={handleChange} />}
                        label="Active"
                    />
                </Grid2>
                <Box sx={{ flexGrow: 1 }}></Box>
                <Button
                    type="submit"
                    variant="contained"
                    color="primary"
                    sx={{ mt: 2 }}
                    onClick={handleSubmit}
                >
                    Save
                </Button>
            </FormControl>
            {confirmation &&
                <ConfirmationDialog
                    message={message}
                    onConfirm={() => {
                        setConfirmation(false)
                    }}
                    title={title}
                />
            }
            <Loader isLoading={loading} />
        </>
    )
}

export default RegisterReport;