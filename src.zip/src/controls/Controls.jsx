import Input from "./Input";
import Button from "./Button"
import ActionButton from "../tests/ActionButton";
const Controls = {
    Input,
    Button,
    ActionButton
};

export default Controls
