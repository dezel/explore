import React from "react";
import {Button} from "@mui/material"
function SubmitButton()
{
    return (
        <Button  onClick={console.log('my name is...')}>
            
        </Button>
    )

}

export default SubmitButton;