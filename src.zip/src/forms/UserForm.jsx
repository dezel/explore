import React, { useState } from "react";
import Controls from "../controls/Controls";
import Button from "../controls/Button";
import {
  AppBar,
  Box,
  Container,
  Paper,
  Typography,
  Grid2,
} from "@mui/material";
import reportInfo from "../data/reportInfo";

const UserForm = () => {
  const [name, setName] = useState("");
  const [userData, setUserdata] = useState({
    name: "",
    department: "",
    startDate: "",
  });
  const [availReport, setAvailReport] = useState(reportInfo);
  const [allowedReport, setAllowedReport] = useState([]);

  const [sampleList, setSampleList] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserdata((prev) => ({
      ...prev,
      [name]: value,
    }));
    console.log(userData);
  };

  const handleAllowReport = (e) => {
    setAllowedReport((f) => [...f, e.target.value]);
    console.log(e);
  };

  const handleRemoveReport = (e) => {};

  const handleSubmit = () => {
    // console.log(userData);
    // console.log(availReport.pop());
    allowedReport.push(availReport.pop(0));
    console.log(allowedReport);
    setSampleList([
      { id: 1, name: "mike" },
      { id: 2, name: "fred" },
    ]);
  };
  return (
    <>
      <Container>
        <Paper
          variant="outlined"
          sx={{ my: { xs: 3, md: 6 }, p: { xs: 2, md: 3 } }}
        >
          <Typography component="h1" variant="h4" align="center">
            Manage User
          </Typography>
          <Container>
            <Box sx={{ my: 3 }}>
              <Typography variant="h6" gutterBottom>
                Personal Details
              </Typography>
              <Grid2 container spacing={3}>
                <Grid2 xs={12} sm={6}>
                  <Controls.Input
                    size="small"
                    variant="standard"
                    name="name"
                    onChange={handleChange}
                    label="Name"
                    value={userData.name}
                    fullWidth
                    required
                  ></Controls.Input>
                </Grid2>
                <Grid2 xs={12} sm={6}>
                  <Controls.Input
                    size="small"
                    variant="standard"
                    name="department"
                    onChange={handleChange}
                    label="Department"
                    value={userData.department}
                    fullWidth
                  ></Controls.Input>
                </Grid2>
                <Grid2 xs={12} sm={6}>
                  <Controls.Input
                    variant="standard"
                    size="small"
                    name="startDate"
                    onChange={handleChange}
                    label="Start Date"
                    value={userData.startDate}
                    fullWidth
                  ></Controls.Input>
                </Grid2>
              </Grid2>
            </Box>
            <Grid2 container spacing={3}>
              <Grid2 xs={12} sm={6}>
                <h6>Avaliable Report</h6>
                <ul>
                  {availReport.map((report) => (
                    <li onClick={handleAllowReport} key={report.id}>
                      {report.reportName}
                    </li>
                  ))}
                </ul>
              </Grid2>
              <Grid2 xs={12} sm={6}>
                <h6>Allowed Report</h6>
                <ul>
                  {allowedReport.map((report) => (
                    <li key={report.id}>{report.reportName}</li>
                  ))}
                </ul>
              </Grid2>
            </Grid2>
          </Container>
          <Button
            variant="contained"
            size="small"
            text="Save"
            sx={{ mt: 3, ml: 1 }}
            fullWidth
            onClick={handleSubmit}
          />
        </Paper>
      </Container>
    </>
  );
};

export default UserForm;
