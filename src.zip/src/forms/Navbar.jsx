import { Button } from "@mui/material";
import "./navbar.css";
// import "/tests/navbar.css"
import { useNavigate } from "react-router-dom";
import Banner from "../tests/fidelity_logo.png"
import useAutoLogout from "../tests/useAutoLogout";
import { useEffect, useState } from "react";

const Navbar = () => {
    const [user, setUser] = useState()
    const navigate = useNavigate()

    useEffect(() => {
        setUser(JSON.parse(localStorage.getItem("userData")));


    }, [])

    if (!user) {
        navigate('/login')
    }

    const logout = () => {
        setUser(null);
        localStorage.removeItem("user");
        navigate("/login"); // Redirect to login
    };

    useAutoLogout(logout);

    return (
        <div className="navbar">
            <div className="wrapper">
                <div className="banner"></div>
                <img style={{ width: 300, height: 100, marginTop: 50, alignContent: 'left' }} src={Banner} />
                <div className="item">
                    <div style={{ color: '#7c0b2b' }}>Welcome, <strong>{user ? user.other_names : 'User'}</strong></div>
                    <div style={{
                        margin: 0, '&:hover': {
                            cursor: 'pointer',
                        }
                    }} >
                        <Button
                            sx={{
                                color: 'brown',
                                border:'1px solid brown',
                                padding:0.1,
                                '&:hover':{
                                    backgroundColor:'brown',
                                    color:"white"
                                },
                                textTransform:'capitalize'
                            }}
                            onClick={() => {
                                localStorage.clear()
                                navigate('/login')
                            }}>Sign out</Button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Navbar;
