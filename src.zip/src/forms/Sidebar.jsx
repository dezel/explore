import { Box, Grid2 } from "@mui/material";

import { grey, pink, red } from "@mui/material/colors";
import './sidebar.css'

function Sidebar() {

    return (
        <>
            {/* <Grid2 xs={6}>
                <Grid2 sx={{ height: 200, background: pink }} container spacing={8} >
                    Button
                </Grid2>

                {/* <Grid2 xs={6} container spacing={8} >
                    Home
                </Grid2> 

            </Grid2> */}

            {/* <Box  className='sidebar'>

                <div></div>
            </Box> */}
            <Box>
                <Grid2 sx={{margin:10, backgroundColor: '#888'}} container spacing={3}>
                    <Grid2 size={4} sx={{backgroundColor:'#7451f8'}}>
                         White background
                    </Grid2>
                    <Grid2 size={8} sx={{backgroundColor:'#6439ff'}}>
                         Other background
                    </Grid2>
                </Grid2>
            </Box>

        </>

    )
}


export default Sidebar;