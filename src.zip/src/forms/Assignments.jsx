import React, { useState } from "react";
import _UserGroups from '../tests/da_user_groups.json'
import { Grid2, Button, Box, backdropClasses } from "@mui/material";
import VerticalLine from "../tests/VerticalLine";


function Assignments() {
    const [userGroups, setUserGroups] = useState(_UserGroups)
    const [assignedUserGroups, setAssignedUserGroups] = useState([])
    const [hoveredRow, setHoveredRow] = useState(null)


    const userGroupRows = userGroups.map((userGroup =>
        <tr
            // onClick={() => assignGroup(userGroup)} key={userGroup.GROUP_ID}
            onMouseEnter={() => setHoveredRow(userGroup.GROUP_ID)}
            onMouseLeave={() => setHoveredRow(null)}
            style={{
                backgroundColor: hoveredRow === userGroup.GROUP_ID ? "#807e93" : "transparent",
                border: "3px solid #333",
                cursor: "pointer",
            }}
        >
            {/* <td>{userGroup.GROUP_ID}</td> */}
            <td>{userGroup.GROUP_NAME}</td>
            <td><button onClick={() => assignGroup(userGroup)}>Assign</button>
            <button>Deny</button></td>
        </tr>))

    const assignedGroupRows = assignedUserGroups.map((assignedUserGroup =>
        <tr
            onClick={() => unassignGroup(assignedUserGroup)} key={assignedUserGroup.GROUP_ID}
            onMouseEnter={() => setHoveredRow(assignedUserGroup.GROUP_ID)}
            onMouseLeave={() => setHoveredRow(null)}
            style={{
                backgroundColor: hoveredRow === assignedUserGroup.GROUP_ID ? "#807e93" : "transparent",
                border: "1px solid #ddd",
                cursor: "pointer",
                '&:hover':{
                    cursor:'pointer'
                }
            }}
        >
            <td>{assignedUserGroup.GROUP_NAME}</td>
        </tr>))

    const itemStyle = {
        textAlign: 'center',
        backgroundColor: '#807e93',
        padding: '1px',
        borderRadius: '1px',
    };

    function assignGroup(assignedGroup) {
        const exists = assignedUserGroups.map((assigned => assigned.GROUP_ID === assignedGroup.GROUP_ID))

        if (exists.every((x => x === false))) {
            setAssignedUserGroups(g => [...g, assignedGroup])
        }
    }
    function unassignGroup(unassignedGroup) {
        setAssignedUserGroups(assignedUserGroups.filter((group => group.GROUP_ID !== unassignedGroup.GROUP_ID)))
    }

    //sx={{ fontFamily: 'Roboto', fontSize: 14, color: '#000022' }} 
    return (
        <>
            <Grid2 container >
                <Grid2 xs={3}>
                    <label><strong>User Groups</strong></label>
                    <table style={{maxHeight:200}}>
                        <tbody>
                            {userGroupRows}
                        </tbody>
                    </table>
                </Grid2>
                <div style={itemStyle}></div>
                <Grid2 xs={3}>
                    <label><strong>Assigned Groups</strong></label>
                    <table style={{maxHeight:200}}>
                        <tbody>
                            {assignedGroupRows}
                        </tbody>
                    </table>
                </Grid2>
                <div style={itemStyle}></div>
                <Grid2 xs={3}>
                    <label><strong>Denied Groups</strong></label>
                    <table style={{maxHeight:200}}>
                        <tbody>
                            {assignedGroupRows}
                        </tbody>
                    </table>
                </Grid2>
            </Grid2>
            {/* <Controls.Button variant='outlined'></Controls.Button> */}
            {/* <Controls.Button>Save</Controls.Button> */}
            <Box textAlign='center'>
                {/* <Button variant="outlined">Save</Button> */}
            </Box>
        </>
    )
}
export default Assignments