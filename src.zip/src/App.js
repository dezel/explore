import "./App.css";
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";

import Login from "./tests/Login";
import HomePage from "./tests/HomePage";
import InputWithAdornment from "./tests/InputWithAdornment";
function App() {
  return (
    <>
    {/* <InputWithAdornment/> */}
      <div style={{ maxHeight: "100vh" }}>
        {/* <Router> */}
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route exact path="/home/*" element={<HomePage />} />
            <Route path="*" element={<Login />} />
            <Route path="/" element={<Login />} />
          </Routes>
        {/* </Router> */}
      </div>
    </>
  );
}

export default App;
