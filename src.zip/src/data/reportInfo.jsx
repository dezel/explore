import React from "react";

const reportInfo = [
    {id:1, reportName: "Daily Branch Transactions"},
    {id:2, reportName: "Daily Momo Transactions"}
]

export default reportInfo
